<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Categories_model extends CI_Model
{

    public function getCategories()
    {
        return $this->db->get('categories');
    }

    public function getCategoriesLimit()
    {
        return $this->db->get('categories');
    }

    public function getCategoryById($id)
    {
        return $this->db->get_where('categories', ['id' => $id])->row_array();
    }

    public function getIdCategoryBySlug($slug)
    {
        $this->db->where('slug', $slug);
        $return = $this->db->get('categories')->row_array();
        return $return;
    }

    public function getNameCategoryBySlug($slug)
    {
        $this->db->where('slug', $slug);
        $return = $this->db->get('categories')->row_array();
        return $return['name'];
    }

    public function insertCategory()
    {
        $name = $this->input->post('name');
        $slug = $this->textToSlug($name);
        $data = [
            "name" => $name,
            "slug" => $slug
        ];
        $this->db->insert('categories', $data);
    }

    function textToSlug($text = '')
    {
        $text = trim($text);
        if (empty($text)) return '';
        $text = preg_replace("/[^a-zA-Z0-9\-\s]+/", "", $text);
        $text = strtolower(trim($text));
        $text = str_replace(' ', '-', $text);
        $text = preg_replace('/\-{2,}/', '-', $text);
        return $text;
    }

    public function updateCategory($id)
    {
        $name = $this->input->post('name');
        $slug =  strtolower($name);
        $slugFix = str_replace(" ", "-", $slug);
        $data = [
            'name' => $name,
            'slug' => $slugFix
        ];
        $this->db->where('id', $id);
        $this->db->update('categories', $data);
    }
}
