<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Products_model extends CI_Model
{

    public function getProducts($number, $offset)
    {
        $this->db->select("*, products.id AS productsId, products.title AS productsTitle, products.variant1_price AS productsPrice, products.date_submit AS productsDate, products.img AS productsImg, products.slug AS slugP, categories.name AS categoryName");
        $this->db->join("categories", "products.category=categories.id");
        $this->db->order_by("products.id", "desc");
        return $this->db->get("products", $number, $offset);
    }

    public function getRating($product, $number, $offset)
    {
        $this->db->order_by('id', 'desc');
        $this->db->where('product', $product);
        $this->db->where('active', 1);
        return $this->db->get('rating', $number, $offset);
    }

    public function rowRatingByProduct($product)
    {
        $this->db->select_avg('star');
        $this->db->where('product', $product);
        $this->db->where('active', 1);
        $result = $this->db->get('rating');
        return $result->row_array()['star'] * 1;
    }

    public function getAllProducts($start)
    {
        $this->db->where('publish', 1);
        $this->db->order_by('id', 'desc');
        $this->db->limit(12, $start);
        return $this->db->get('products');
    }

    public function getAllProductBestSeller($start)
    {
        $this->db->where('publish', 1);
        $this->db->order_by('transaction', 'desc');
        $this->db->limit(12, $start);
        return $this->db->get('products');
    }

    public function getRelatedProduct($category, $limit)
    {
        $this->db->where('category', $category);
        $this->db->where('publish', 1);
        $this->db->order_by('transaction', "asc");
        $this->db->order_by('viewer', "asc");
        $this->db->limit($limit);
        return $this->db->get('products');
    }

    public function searchProducts($q, $type = "")
    {
        if ($type == "") {
            $this->db->where('publish', 1);
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "az") {
            $this->db->where('publish', 1);
            $this->db->order_by('title', 'asc');
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "za") {
            $this->db->where('publish', 1);
            $this->db->order_by('title', 'desc');
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "pricemax") {
            $this->db->where('publish', 1);
            $this->db->order_by('price', 'asc');
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "pricemin") {
            $this->db->where('publish', 1);
            $this->db->order_by('price', 'desc');
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "promo") {
            $this->db->where('publish', 1);
            $this->db->where('promo_price != 0');
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "1") {
            $this->db->where('publish', 1);
            $this->db->where('condit', 1);
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else if ($type == "2") {
            $this->db->where('publish', 1);
            $this->db->where('condit', 2);
            $this->db->like('title', $q);
            return $this->db->get('products');
        }
    }

    public function searchProductsPrice($q, $min, $max)
    {
        if ($max == "0") {
            $this->db->where('publish', 1);
            $this->db->where('price >=', $min);
            $this->db->like('title', $q);
            return $this->db->get('products');
        } else {
            $this->db->where('publish', 1);
            $this->db->where('price >=', $min);
            $this->db->where('price <=', $max);
            $this->db->like('title', $q);
            return $this->db->get('products');
        }
    }

    public function getAllProductsByCategory($c, $start, $sort)
    {
        $this->db->where('publish', 1);
        $this->db->where('category', $c);
        if ($sort == "bestseller") {
            $this->db->order_by('transaction', 'desc');
        } else if ($sort == "latest") {
            $this->db->order_by('id', 'desc');
        } else if ($sort == "cheapest") {
            $this->db->order_by('price', 'asc');
        } else if ($sort == "expensive") {
            $this->db->order_by('price', 'desc');
        } else if ($sort == "") {
            $this->db->order_by('id', 'desc');
        }
        return $this->db->get('products');
    }

    public function getAllProductsPrice($min, $max)
    {
        if ($max == "0") {
            $this->db->where('publish', 1);
            $this->db->where('price >=', $min);
            return $this->db->get('products');
        } else {
            $this->db->where('publish', 1);
            $this->db->where('price >=', $min);
            $this->db->where('price <=', $max);
            return $this->db->get('products');
        }
    }

    public function getAllProductsByCategoryPrice($cat, $min, $max)
    {
        if ($max == "0") {
            $this->db->where('publish', 1);
            $this->db->where('category', $cat);
            $this->db->where('price >=', $min);
            return $this->db->get('products');
        } else {
            $this->db->where('publish', 1);
            $this->db->where('category', $cat);
            $this->db->where('price >=', $min);
            $this->db->where('price <=', $max);
            return $this->db->get('products');
        }
    }

    public function getImgProductBySlug($slug)
    {
        $product = $this->db->get_where('products', ['slug' => $slug])->row_array();
        return $this->db->get_where('img_product', ['id_product' => $product['id']]);
    }

    public function getProductsLimit($start)
    {
        $this->db->where('publish', 1);
        $this->db->order_by("id", "desc");
        $this->db->limit(9, $start);
        return $this->db->get("products");
    }

    public function getProductsByCategoryLimit($id, $start)
    {
        $this->db->where('publish', 1);
        $this->db->where('category', $id);
        $this->db->order_by("id", "desc");
        $this->db->limit(6, $start);
        return $this->db->get("products");
    }

    public function getBestProductsLimit()
    {
        $this->db->select("*");
        $this->db->from("products");
        $this->db->order_by("transaction", "desc");
        $this->db->limit(4);
        $this->db->where('publish', 1);
        return $this->db->get();
    }

    public function getTransactionByInvoice($id)
    {
        return $this->db->get_where('transaction', ['id_invoice' => $id]);
    }

    public function getProductById($id)
    {
        $this->db->select("*,products.id AS productId, products.slug AS slugP");
        $this->db->from("products");
        $this->db->join("categories", "products.category=categories.id");
        $this->db->where('products.id', $id);
        return $this->db->get()->row_array();
    }

    public function getProductBySlug($slug)
    {
        $this->db->select("*,products.id AS productId, categories.slug AS cSlug, products.slug AS slugP");
        $this->db->from("products");
        $this->db->join("categories", "products.category=categories.id");
        $this->db->order_by("products.id", "desc");
        $this->db->where('products.slug', $slug);
        return $this->db->get()->row_array();
    }

    function resize_crop($config, $resize_width, $resize_height)
    {
        if ($config) {
            $CI = &get_instance();
            $CI->load->library('image_lib');

            $img_size = getimagesize($config['source_image']);

            $t_ratio = $resize_width / $resize_height;
            $o_width = $img_size[0];
            $o_height = $img_size[1];
            if ($t_ratio > $o_width / $o_height) {
                $config['width'] = $resize_width;
                $config['height'] = round($resize_width * ($o_height / $o_width));
                $y_axis = round(($config['height'] / 2) - ($resize_height / 2));
                $x_axis = 0;
            } else {
                $config['width'] = round($resize_height * ($o_width / $o_height));
                $config['height'] = $resize_height;
                $y_axis = 0;
                $x_axis = round(($config['width'] / 2) - ($resize_width / 2));
            }

            $source_img01 = $config['new_image'];

            $CI->image_lib->clear();
            $CI->image_lib->initialize($config);
            $CI->image_lib->resize();

            $config['image_library'] = 'gd2';
            $config['source_image'] = $source_img01;
            $config['create_thumb'] = false;
            $config['maintain_ratio'] = false;
            $config['width'] = $resize_width;
            $config['height'] = $resize_height;
            $config['y_axis'] = $y_axis;
            $config['x_axis'] = $x_axis;

            $CI->image_lib->clear();
            $CI->image_lib->initialize($config);
            $CI->image_lib->crop();

            return $config['new_image'];
        }
        return FALSE;
    }

    public function uploadImg()
    {
        $config['upload_path'] = './assets/images/product/';
        $config['allowed_types'] = 'jpg|png|jpeg|image/png|image/jpg|image/jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = round(microtime(true) * 1000);

        $this->load->library('upload', $config);
        if ($this->upload->do_upload('img')) {
            $gbr = $this->upload->data();
            $config['image_library'] = 'gd2';
            $config['source_image'] = './assets/images/product/' . $gbr['file_name'];
            $config['new_image'] = './assets/images/product/' . $gbr['file_name'];
            $this->resize_crop($config, '900', '600');
            $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
            return $return;
        } else {
            $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
            return $return;
        }
    }
    public function insertImg($upload, $id)
    {
        $data = [
            'id_product' => $id,
            'img' => $upload['file']['file_name']
        ];
        $this->db->insert('img_product', $data);
    }

    public function insertProduct($upload)
    {
        $idProduct = $this->db->query('SELECT * FROM products ORDER BY id DESC LIMIT 1')->row_array()['id'] + 1;
        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $description = $this->input->post('description');
        $variant1 = $this->input->post('variant1');
        $variant1_price = $this->input->post('variant1_price');
        $variant1_discount = $this->input->post('variant1_discount');
        $variant2 = $this->input->post('variant2');
        $variant2_price = $this->input->post('variant2_price');
        $variant2_discount = $this->input->post('variant2_discount');
        $img = $upload == "" ? "" : $upload['file']['file_name'];
        $imgReal = "";
        $date_submit = date("Y-m-d H:i:s");
        $publish = $this->input->post('publish');
        $video_yt = $this->input->post('video_yt');
        function textToSlug($text = '')
        {
            $text = trim($text);
            if (empty($text)) return '';
            $text = preg_replace("/[^a-zA-Z0-9\-\s]+/", "", $text);
            $text = strtolower(trim($text));
            $text = str_replace(' ', '-', $text);
            $text = preg_replace('/\-{2,}/', '-', $text);
            return $text;
        }
        $slug = textToSlug($title) . time();

        $data = [
            "id" => $idProduct,
            "title" => $title,
            "category" => $category,
            "description" => $description,
            "variant1" => $variant1,
            "variant1_price" => $variant1_price,
            "variant1_discount" => $variant1_discount,
            "variant2" => $variant2,
            "variant2_price" => $variant2_price,
            "variant2_discount" => $variant2_discount,
            "publish" => $publish,
            "video_yt" => $video_yt,
            "date_submit" => $date_submit,
            "slug" => $slug,
        ];
        if ($img != "") {
            $config['upload_path'] = './assets/images/product/';
            $config['allowed_types'] = 'jpg|png|jpeg|image/png|image/jpg|image/jpeg';
            $config['max_size'] = '2048';
            $config['file_name'] = round(microtime(true) * 1000);
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('img')) {
                $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
                $imgReal = $return['file']['file_name'];
            }
            $data['img'] = $img;
            $data['img_real'] = $imgReal;
        }
        $this->db->insert('products', $data);
        $idInsertProduct = $idProduct;

        $variant1_point = $this->input->post('variant1_point');
        foreach ($variant1_point as $key => $value) {
            if ($_POST['variant1_point'][$key] != "") {
                $result = [
                    'id_product' => $idInsertProduct,
                    'type' => 1,
                    'point' => $_POST['variant1_point'][$key]
                ];
                $this->db->insert('variant_point', $result);
            }
        }

        $variant2_point = $this->input->post('variant2_point');
        foreach ($variant2_point as $key => $value) {
            if ($_POST['variant2_point'][$key] != "") {
                $result = [
                    'id_product' => $idInsertProduct,
                    'type' => 2,
                    'point' => $_POST['variant2_point'][$key]
                ];
                $this->db->insert('variant_point', $result);
            }
        }
    }

    public function updateProduct($upload, $id)
    {
        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $description = $this->input->post('description');
        $variant1 = $this->input->post('variant1');
        $variant1_price = $this->input->post('variant1_price');
        $variant1_discount = $this->input->post('variant1_discount');
        $variant2 = $this->input->post('variant2');
        $variant2_price = $this->input->post('variant2_price');
        $variant2_discount = $this->input->post('variant2_discount');
        $publish = $this->input->post('publish');
        $video_yt = $this->input->post('video_yt');
        $img = $upload == "" ? "" : $upload['file']['file_name'];
        $imgReal = "";
        $data = [
            "title" => $title,
            "category" => $category,
            "description" => $description,
            "variant1" => $variant1,
            "variant1_price" => $variant1_price,
            "variant1_discount" => $variant1_discount,
            "variant2" => $variant2,
            "variant2_price" => $variant2_price,
            "variant2_discount" => $variant2_discount,
            "publish" => $publish,
            "video_yt" => $video_yt
        ];
        if ($img != "") {
            $config['upload_path'] = './assets/images/product/';
            $config['allowed_types'] = 'jpg|png|jpeg|image/png|image/jpg|image/jpeg';
            $config['max_size'] = '2048';
            $config['file_name'] = round(microtime(true) * 1000);
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('img')) {
                $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
                $imgReal = $return['file']['file_name'];
            }
            $data['img'] = $img;
            $data['img_real'] = $imgReal;
        }
        $this->db->where('id', $id);
        $this->db->update('products', $data);

        $this->db->where('id_product', $id);
        $this->db->delete('variant_point');
        $variant1_point = $this->input->post('variant1_point');
        foreach ($variant1_point as $key => $value) {
            if ($_POST['variant1_point'][$key] != "") {
                $result = [
                    'id_product' => $id,
                    'type' => 1,
                    'point' => $_POST['variant1_point'][$key]
                ];
                $this->db->insert('variant_point', $result);
            }
        }
        $variant2_point = $this->input->post('variant2_point');
        foreach ($variant2_point as $key => $value) {
            if ($_POST['variant2_point'][$key] != "") {
                $result = [
                    'id_product' => $id,
                    'type' => 2,
                    'point' => $_POST['variant2_point'][$key]
                ];
                $this->db->insert('variant_point', $result);
            }
        }
    }

    public function updateViewer($slug)
    {
        $result = $this->db->get_where('products', ['slug' => $slug])->row_array();
        $newV = (int)$result['viewer'] + 1;
        $this->db->set('viewer', $newV);
        $this->db->where('id', $result['id']);
        $this->db->update('products');
    }
}
