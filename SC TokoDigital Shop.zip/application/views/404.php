<style>
  div.wrapper {
    margin: 50px;
    margin-bottom: 100px
  }

  div.wrapper img {
    width: 700px;
    left: 50%;
    transform: translate(-50%,0);
    position: relative;
  }

  div.wrapper h4 {
    margin-top: 20px;
    text-align: center;
  }

  div.wrapper button {
    background-color: <?= $this->Settings_model->general()['navbar_color']; ?>;
    color: white;
    border: none;
    border-radius: 6px;
    left: 50%;
    transform: translate(-50%,0);
    margin: auto;
    padding: 10px 30px;
    outline: none;
    position: relative;
    margin-top: 20px;
  }

  @media screen and (max-width: 750px){
    div.wrapper img {
      width: 90%;
    }
  }
</style>

<div class="wrapper">
  <img src="<?= base_url(); ?>assets/images/icon/404.png" alt="404">
  <h4>Maaf, halaman tidak ditemukan</h4>
  <a href="<?= base_url(); ?>"><button><i class="fa fa-home"></i> Kembali ke Home</button></a>
</div>