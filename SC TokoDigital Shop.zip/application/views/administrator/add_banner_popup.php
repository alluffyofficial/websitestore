<?php echo $this->session->flashdata('upload'); ?>

<div class="container-fluid">
  <h1 class="h4 mb-2 text-gray-800 mb-4">Buat Banner</h1>

  <div class="card shadow mb-4">
    <div class="card-body">
      <?= $this->session->flashdata('failed'); ?>
      <form action="<?= base_url(); ?>administrator/banner-popup/add" method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label for="img">Gambar Banner</label>
          <input type="file" name="img" id="img" required class="form-control-file">
        </div>
        <div class="form-group">
          <label for="delay">Delay Popup</label>
          <input type="number" autocomplete="off" id="delay" name="delay" required class="form-control">
          <small class="text-secondary">Ketik angka, maka banner akan muncul dalam hitungan detik</small>
        </div>
        <div class="form-group">
          <label for="url">URL</label>
          <input type="text" autocomplete="off" id="url" name="url" required class="form-control">
          <small class="text-secondary">Jika banner diklik maka akan mengarah ke link/url diatas. Misal: https://domain.com/p/produk-keren</small>
        </div>
        <button class="btn btn-primary">TAMBAH</button>
        <a href="<?= base_url(); ?>administrator/banner-popup" class="btn btn-danger">BATAL</a>
      </form>
    </div>
  </div>
</div>