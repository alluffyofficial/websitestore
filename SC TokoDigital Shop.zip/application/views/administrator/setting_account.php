<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan Akun</h1>

<div class="card">
    <div class="card-body">
        <?php include 'setting_menu.php'; ?>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/setting/account" method="post">
            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <label for="wa">Nomor Whatsapp Admin</label>
                        <input type="number" name="wa" id="wa" placeholder="62.." autocomplete="off" class="form-control" value="<?= $setting['wa_admin']; ?>">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <label for="opening_chat">Salam Pembuka</label>
                        <input type="text" maxlength="200" name="opening_chat" id="opening_chat" autocomplete="off" class="form-control" value="<?= $setting['opening_chat']; ?>">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-4">Simpan Pengaturan</button>
        </form>
    </div>
</div>