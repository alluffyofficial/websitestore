<?php echo $this->session->flashdata('upload'); ?>
<?php include __DIR__ . '/../templates/star.php' ?>

<h1 class="h4 mb-4 text-gray-800">Rating Produk: <?= $product['title'] ?></h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-body">
    <?php echo $this->session->flashdata('failed'); ?>
    <?php if ($rating->num_rows() > 0) { ?>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th style="width: 110px">Bintang</th>
              <th>Review</th>
              <th style="width: 80px">Aksi</th>
            </tr>
          </thead>
          <tfoot></tfoot>
          <tbody class="data-content">
            <?php $no = 1 ?>
            <?php foreach ($rating->result_array() as $data) : ?>
              <tr>
                <td><?= $no; ?></td>
                <td><?= $data['name']; ?></td>
                <td style="color: orange;"><?= rattingStars($data['star']); ?></td>
                <td><?= $data['review']; ?></td>
                <td>
                  <?php if ($data['active'] == 0) { ?>
                    <a href="<?= base_url(); ?>administrator/confirm_rating/<?= $data['id']; ?>?redirect=ratings_product/<?= $product['id'] ?>" class="h5 mr-3 text-success"><i class="fa fa-check-circle"></i></a>
                  <?php } ?>
                  <a href="<?= base_url(); ?>administrator/delete_rating/<?= $data['id']; ?>?redirect=ratings_product/<?= $product['id'] ?>" onclick="return confirm('Yakin ingin menghapus rating ini?');" class="h5 text-danger"><i class="fa fa-trash-alt"></i></a>
                </td>
              </tr>
              <?php $no++ ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php } else { ?>
      <div class="alert alert-warning" role="alert">
        Opss, belum ada rating untuk produk ini.
      </div>
    <?php } ?>
  </div>
</div>