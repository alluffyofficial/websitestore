<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <a href="<?= base_url(); ?>administrator/design/banner/add" class="btn btn-primary mb-4 px-4">TAMBAH</a>
        <?php if($banner->num_rows() > 0){ ?>
        <table class="table table-bordered">
            <tr>
                <th>Gambar</th>
                <th>URL</th>
                <th>Aksi</th>
            </tr>
            <?php foreach($banner->result_array() as $d): ?>
                <tr>
                    <td><img style="width: 80%" src="<?= base_url(); ?>assets/images/banner/<?= $d['img']; ?>" alt=""></td>
                    <td><?= $d['url']; ?></td>
                    <td class="text-center">
                        <a href="<?= base_url() ;?>administrator/delete_banner/<?= $d['id']; ?>" onclick="return confirm('Yakin ingin menghapus banner ini?')" class="text-danger h5"><i class="fa fa-trash-alt"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <?php }else{ ?>
            <div class="alert alert-warning">Belum ada banner</div>
        <?php } ?>
    </div>
</div>