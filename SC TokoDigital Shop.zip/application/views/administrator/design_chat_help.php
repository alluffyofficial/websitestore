<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
    <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/design/chat-help" method="post">
        <?php echo $this->session->flashdata('failed'); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <?php if($setting['chat_help'] == 1){ ?>
                                <input type="checkbox" checked class="custom-control-input" id="chatHelpStatusDesign">
                            <?php }else{ ?>
                                <input type="checkbox" class="custom-control-input" id="chatHelpStatusDesign">
                            <?php } ?>
                            <label class="custom-control-label" for="chatHelpStatusDesign">Aktifkan Chat Help</label>
                        </div>
                        <small class="text-success" style="display: none" id="msgChatHelpStatusDesign">Berhasil mengubah</small>
                    </div>
                    <div class="form-group">
                        <label for="message" class="d-block">Salam Pembuka</label>
                        <small class="text-secondary">Pesan salam pembuka yang akan muncul di pesan bantuan user</small>
                        <input type="text" id="message" name="message" class="form-control" autocomplete="off" value="<?= $setting['message_chat_help'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="color" class="d-block">Warna</label>
                        <input type="text" autocomplete="off" name="color" id="colorPicker" required value="<?= $setting['color_chat_help'] ?>" class="form-control">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-3">Simpan Pengaturan</button>
        </form>
    </div>
</div>