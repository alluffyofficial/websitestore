<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <a href="<?= base_url(); ?>administrator/design/footer" class="text-secondary">Tentang Kami</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="text-secondary">Sosial Media</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/payment" class="text-secondary">Logo Pembayaran</a>
        </div>
        <button data-toggle="modal" data-target="#addNav" class="btn btn-primary mt-3 px-3">TAMBAH</button>
        <?php if ($footer->num_rows() > 0) { ?>
            <table class="table mt-2 table-bordered">
                <tr>
                    <th>Judul</th>
                    <th>Aksi</th>
                </tr>
                <?php foreach ($footer->result_array() as $d) : ?>
                    <tr>
                        <td><?= $d['title']; ?></td>
                        <td style="width: 60px">
                            <a href="<?= base_url(); ?>administrator/delete_footer/<?= $d['footerid']; ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-sm btn-danger"><i class="fa fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php } else { ?>
            <div class="alert mt-3 alert-warning">Belum ada footer.</div>
        <?php } ?>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addNav" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Halaman</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url(); ?>administrator/design/footer/help" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="page">Pilih Halaman</label>
                        <select class="form-control" name="page" id="page">
                            <?php foreach ($pages->result_array() as $p) : ?>
                                <?php if ($this->db->get_where('footer', ['page' => $p['id']])->num_rows() < 1) { ?>
                                    <option value="<?= $p['id']; ?>"><?= $p['title']; ?></option>
                                <?php } ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn px-3 btn-info">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>