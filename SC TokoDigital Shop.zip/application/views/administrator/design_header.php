<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
    <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/design/header" method="post" enctype="multipart/form-data">
        <?php echo $this->session->flashdata('failed'); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="name">Nama Toko</label>
                        <input type="text" id="name" class="form-control" name="name" autocomplete="off" required value="<?= $general['app_name']; ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="contact">Kontak Toko</label>
                        <input type="text" id="contact" class="form-control" name="contact" autocomplete="off" required value="<?= $general['contact']; ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="logo-dark">Logo Toko</label>
                        <?php if($general['logo-dark'] != ""){ ?>
                            <br>
                            <img src="<?= base_url(); ?>assets/images/logo/<?= $general['logo-dark'] ?>" alt="logo" height="50">
                        <?php } ?>
                        <input type="file" name="logo-dark" id="logo-dark" class="form-control-file">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="favicon">Favicon</label>
                        <?php if($general['favicon'] != ""){ ?>
                            <br>
                            <img src="<?= base_url(); ?>assets/images/logo/<?= $general['favicon'] ?>" class="mb-2" alt="favicon" height="50">
                        <?php } ?>
                        <input type="file" name="favicon" id="favicon" class="form-control-file">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="colorPicker2">Warna Tombol</label>
                        <input type="text" autocomplete="off" name="btncolor" id="colorPicker2" required class="form-control" value="<?= $general['btncolor'] ?>">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-3">Simpan Pengaturan</button>
        </form>
    </div>
</div>