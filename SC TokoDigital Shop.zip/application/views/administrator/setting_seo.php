<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan SEO</h1>

<div class="card">
    <div class="card-body">
        <?php include 'setting_menu.php'; ?>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/setting/seo" method="post">
            <input type="hidden" name="helper" value="true">
            <div class="form-group mt-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="gaID">Google Analitics ID</label>
                            <input type="text" placeholder="UA-#####-#" name="gaID" id="gaID" autocomplete="off" class="form-control" value="<?= $setting['ga_id']; ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="gsConsole">Google Search Console</label>
                            <input type="text" name="gsConsole" id="gsConsole" autocomplete="off" class="form-control" value='<?= $setting['gs_console']; ?>'>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-4">Simpan Pengaturan</button>
        </form>
    </div>
</div>