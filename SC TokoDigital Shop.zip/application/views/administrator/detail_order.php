<?php echo $this->session->flashdata('upload'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h4 mb-4 text-gray-800 mb-2">Order ID : <?= $invoice['invoice_code']; ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url(); ?>administrator/orders" class="btn mr-2 btn-primary px-4"><i class="fa fa-chevron-left"></i> Kembali</a>
            <a href="<?= base_url(); ?>administrator/print_invoice_order/<?= $invoice['invoice_code']; ?>" target="_blank" class="btn float-right mr-2 btn-danger px-4">INVOICE</a>
        </div>
        <div class="card-body">
            <h3 class="lead font-weight-bold">DATA PENERIMA</h3>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td>Nama Penerima</td>
                            <td>: <?= $invoice['name']; ?></td>
                        </tr>
                        <tr>
                            <td>No Handphone</td>
                            <td>: <?= $invoice['telp']; ?></td>
                        </tr>
                    </table>
                    <br>
                    <h3 class="lead font-weight-bold">DATA ORDER</h3>
                    <hr>
                    <table class="table table-bordered">
                        <tr>
                            <th class="text-center">No.</th>
                            <th class="text-center">Nama Produk</th>
                            <th class="text-center">Varian</th>
                            <th class="text-center">Banyak</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Lihat</th>
                            <?php $no = 1;
                            foreach ($orders->result_array() as $data) : ?>
                        </tr>
                        <td class="text-center"><?= $no; ?></td>
                        <td><?= $data['product_name']; ?></td>
                        <td class="text-center"><?= $data['variant']; ?></td>
                        <td class="text-center"><?= $data['qty']; ?></td>
                        <td>Rp<?= number_format($data['price'], 0, ",", "."); ?></td>
                        <?php $total = $data['price'] * $data['qty']; ?>
                        <td>Rp<?= number_format($total, 0, ",", "."); ?></td>
                        <td>
                            <a href="<?= base_url(); ?>p/<?= $data['slug']; ?>" target="_blank" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></a>
                        </td>
                        <tr>
                        <?php $no++;
                            endforeach; ?>
                        </tr>
                    </table>
                    <div class="col-md-6">
                        <table class="table table-borderless table-sm">
                            <tr>
                                <td>Total Harga</td>
                                <td>: Rp <?= number_format($invoice['total_price'], 0, ",", "."); ?></td>
                            </tr>
                            <?php if ($invoice['uniq_number'] != 0) { ?>
                                <tr>
                                    <td>Kode Unik</td>
                                    <td>: Rp <?= $invoice['uniq_number']; ?></td>
                                </tr>
                            <?php } ?>
                            <?php if ($invoice['potongan'] != 0) { ?>
                                <tr>
                                    <td>Potongan</td>
                                    <td>: Rp <?= number_format($invoice['potongan'], 0, ",", "."); ?></td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <th>Total Keseluruhan</th>
                                <th>: Rp <?= number_format($invoice['total_all'], 0, ",", "."); ?></th>
                            </tr>
                        </table>
                    </div>
                    <hr>
                    <?php if ($invoice['status'] == 0) { ?>
                        <a href="<?= base_url(); ?>administrator/order/<?= $invoice['invoice_code']; ?>/process" onclick="return confirm('Yakin ingin mengkonfirmasi pembayaran?');" class="btn mr-3 btn-success px-4">Konfirmasi Pembayaran</a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->