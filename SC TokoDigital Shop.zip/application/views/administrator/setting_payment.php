<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan Pembayaran</h1>

<div class="card">
    <div class="card-body">
        <?php include 'setting_menu.php'; ?>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="alert alert-success" id="msgSettingPayment" style="display: none"></div>
        <div class="d-flex">
            <div class="form-group">
                <div class="custom-control mr-5 custom-switch">
                    <?php if ($setting['payment_feature'] == 1) { ?>
                        <input type="checkbox" checked class="custom-control-input" id="paymentFeatureSetting">
                    <?php } else { ?>
                        <input type="checkbox" class="custom-control-input" id="paymentFeatureSetting">
                    <?php } ?>
                    <label class="custom-control-label" for="paymentFeatureSetting">Aktifkan Fitur Pembayaran</label>
                </div>
            </div>
            <div class="form-group">
                <div class="custom-control mr-5 custom-switch">
                    <?php if ($setting['uniq_code_feature'] == 1) { ?>
                        <input type="checkbox" checked class="custom-control-input" id="uniqCodeFeatureSetting">
                    <?php } else { ?>
                        <input type="checkbox" class="custom-control-input" id="uniqCodeFeatureSetting">
                    <?php } ?>
                    <label class="custom-control-label" for="uniqCodeFeatureSetting">Aktifkan Kode Unik</label>
                </div>
            </div>
            <div class="form-group" style="display: <?= $setting['uniq_code_feature'] == 1 ? "block" : "none" ?>;" id="formGroupAddminUniqPayment">
                <select name="addmin_uniq" id="addmin_uniq" class="form-control">
                    <option <?= $setting['addmin_uniq'] == 1 ? "selected" : "" ?> value="1">Tambahkan Harga</option>
                    <option <?= $setting['addmin_uniq'] == 2 ? "selected" : "" ?> value="2">Kurangi Harga</option>
                </select>
            </div>
        </div>
        <form action="<?= base_url(); ?>administrator/save_setting_payment" method="post">
            <?php foreach ($rekening->result_array() as $r) : ?>
                <div class="form-group mt-3" id="formSectionSettingPayment-<?= $r['rekeningId']; ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <select name="rekening[]" id="rekening" class="form-control">
                                <option value="<?= $r['rekening'] ?>"><?= $r['bankName'] ?></option>
                                <?php foreach ($bank->result_array() as $d) : ?>
                                    <?php if ($r['rekening'] != $d['id']) { ?>
                                        <option value="<?= $d['id'] ?>"><?= $d['name']; ?></option>
                                    <?php } ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="number[]" id="number" autocomplete="off" class="form-control" value="<?= $r['number']; ?>">
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="name[]" id="name" autocomplete="off" class="form-control" placeholder="Nama Pemilik Rekening" value="<?= $r['rekeningName']; ?>">
                        </div>
                        <input type="hidden" name="rekeningId[]" value="<?= $r['rekeningId']; ?>">
                        <div class="col-sm-1">
                            <i onclick="deleteRekening('<?= $r['rekeningId']; ?>')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="form-add-bank-in-here-payment-setting">
                <div class="form-group mt-3" id="formSectionSettingPayment-1">
                    <div class="row">
                        <div class="col-md-4">
                            <select name="rekening[]" id="rekening" class="form-control">
                                <option value="0">Pilih Bank</option>
                                <?php foreach ($bank->result_array() as $d) : ?>
                                    <option value="<?= $d['id'] ?>"><?= $d['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="number[]" id="number" autocomplete="off" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="name[]" id="name" autocomplete="off" class="form-control" placeholder="Nama Pemilik Rekening">
                        </div>
                        <input type="hidden" name="rekeningId[]" value="0">
                        <div class="col-sm-1">
                            <i onclick="removeRekeningForm('1')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
                        </div>
                    </div>
                </div>
            </div>
            <button id="btnAddFormBankPaymentSetting" type="button" class="btn btn-outline-primary">Tambah Pilihan</button><br>
            <button type="submit" class="btn mt-3 btn-primary px-4">Simpan Pengaturan</button>
        </form>
    </div>
</div>

<script src="<?= base_url(); ?>assets/admin/libs/jquery/jquery.min.js"></script>
<script>
    $("#addmin_uniq").on("change", function() {
        $.ajax({
            url: "<?= base_url(); ?>administrator/edit_addmin_uniq",
            method: "post",
            data: {
                option: $(this).val()
            },
            success: function() {
                $("#msgSettingPayment").slideDown('fast');
                $("#msgSettingPayment").text('Berhasil mengubah');
                setTimeout(function() {
                    $("#msgSettingPayment").slideUp('fast');
                }, 3000);
            }
        })
    })
    let globalIdFormBankPaymentSetting = 2;
    $("#btnAddFormBankPaymentSetting").on("click", function() {
        $(".form-add-bank-in-here-payment-setting").append(`
        <div class="form-group mt-3" id="formSectionSettingPayment-${globalIdFormBankPaymentSetting}">
            <div class="row">
                <div class="col-md-4">
                    <select name="rekening[]" id="rekening" class="form-control">
                        <option value="0">Pilih Bank</option>
                        <?php foreach ($bank->result_array() as $d) : ?>
                            <option value="<?= $d['id'] ?>"><?= $d['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="number[]" id="number" autocomplete="off" class="form-control">
                </div>
                <div class="col-md-3">
                    <input type="text" name="name[]" id="name" autocomplete="off" class="form-control" placeholder="Nama Pemilik Rekening">
                </div>
                <input type="hidden" name="rekeningId[]" value="0">
                <div class="col-sm-1">
                    <i onclick="removeRekeningForm('${globalIdFormBankPaymentSetting}')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
                </div>
            </div>
        </div>
        `);
        globalIdFormBankPaymentSetting += 1;
    })
</script>