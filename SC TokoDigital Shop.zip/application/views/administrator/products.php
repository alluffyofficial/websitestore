<?php echo $this->session->flashdata('upload'); ?>
<?php function getThumbnail($url)
{
	preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url, $matches);
	return "https://img.youtube.com/vi/$matches[0]/0.jpg";
} ?>
<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<h4 class="mb-4">Produk</h4>

	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-body py-3">
			<a href="<?= base_url(); ?>administrator/product/add" class="btn btn-primary">Tambah Produk</a>
			<button class="btn btn-success ml-2" data-toggle="modal" data-target="#importProducts">Import</button>
		</div>
		<div class="card-body">
			<?php echo $this->session->flashdata('failed'); ?>
			<?php if ($getProducts->num_rows() > 0) { ?>
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>Foto</th>
								<th>Judul Produk</th>
								<th>Harga</th>
								<th>Total Order</th>
								<th>Kategori</th>
								<th style="width: 130px">Aksi</th>
							</tr>
						</thead>
						<tfoot></tfoot>
						<tbody class="data-content">
							<?php foreach ($getProducts->result_array() as $data) : ?>
								<tr>
									<?php if ($data['productsImg'] == "") { ?>
										<td style="width: 70px"><img src="<?= getThumbnail($data['video_yt']) ?>" style="width: 70px;"></td>
									<?php } else { ?>
										<td style="width: 70px"><img style="width: 70px" src="<?= $data['ex_img'] == 1 ? $data['productsImg'] : base_url() . 'assets/images/product/' . $data['productsImg']; ?>"></td>
									<?php } ?>
									<td><?= $data['productsTitle']; ?></td>
									<td><?= str_replace(",", ".", number_format($data['productsPrice'])); ?></td>
									<td><?= $data['transaction'] ?></td>
									<td><?= $data['categoryName']; ?></td>
									<td width="160px">
										<a href="<?= base_url(); ?>administrator/ratings_product/<?= $data['productsId']; ?>" class="btn btn-sm btn-warning"><i class="fa fa-star"></i></a>
										<a target="_blank" href="<?= base_url(); ?>p/<?= $data['slugP']; ?>" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></a>
										<a href="<?= base_url(); ?>administrator/product/<?= $data['productsId']; ?>/edit" class="btn btn-sm btn-info"><i class="fa fa-pen"></i></a>
										<a href="<?= base_url(); ?>administrator/delete_product/<?= $data['productsId']; ?>" onclick="return confirm('Yakin ingin menghapus produk?')" class="btn btn-sm btn-danger"><i class="fa fa-trash-alt"></i></a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?= $this->pagination->create_links(); ?>
				</div>
			<?php } else { ?>
				<div class="alert alert-warning" role="alert">
					Opss, produk masih kosong, yuk tambah produk sekarang.
				</div>
			<?php } ?>
		</div>
	</div>
</div>

<div class="modal fade" id="importProducts" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Import Produk</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url(); ?>administrator/import_massal_products" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<p class="mt-0"><a target="_blank" href="<?= base_url(); ?>assets/admin/xls/contoh_pengisian_produk.xlsx">Klik disini</a> untuk mengunduh contoh pengisian produk</p>
						<hr>
						<label for="products">File Produk</label>
						<input type="file" class="form-control-file" required name="userfile" id="products" />
					</div>
					<button type="submit" class="btn btn-primary">
						Tambahkan
					</button>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- /.container-fluid -->