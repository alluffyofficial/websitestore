<?php $uri3 = $this->uri->segment(3); ?>
<ul class="nav nav-pills">
  <li class="nav-item">
    <a class="flex-sm-fill <?= $uri3 == "account" ? "text-primary" : "text-secondary" ?> nav-link" href="<?= base_url(); ?>administrator/setting/account"><i class="uil-user-circle"></i> Akun</a>
  </li>
  <li class="nav-item">
    <a class="flex-sm-fill <?= $uri3 == "payment" ? "text-primary" : "text-secondary" ?> nav-link" href="<?= base_url(); ?>administrator/setting/payment"><i class="uil-usd-circle"></i> Pembayaran</a>
  </li>
  <li class="nav-item">
    <a class="flex-sm-fill <?= $uri3 == "notification" ? "text-primary" : "text-secondary" ?> nav-link" href="<?= base_url(); ?>administrator/setting/notification"><i class="uil-comment-alt-dots"></i>
      Notifikasi</a>
  </li>
  <li class="nav-item">
    <a class="flex-sm-fill <?= $uri3 == "pixel" ? "text-primary" : "text-secondary" ?> nav-link" href="<?= base_url(); ?>administrator/setting/pixel"><i class="uil-facebook"></i> Pixel</a>
  </li>
  <li class="nav-item">
    <a class="flex-sm-fill <?= $uri3 == "seo" ? "text-primary" : "text-secondary" ?> nav-link" href="<?= base_url(); ?>administrator/setting/seo"><i class="uil-google"></i> SEO</a>
  </li>
</ul>