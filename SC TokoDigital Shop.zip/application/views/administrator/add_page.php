<?php echo $this->session->flashdata('upload'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<h1 class="h4 mb-2 text-gray-800">Tambah Halaman</h1>

	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-body">
			<?php echo $this->session->flashdata('failed'); ?>
			<form
				action="<?= base_url(); ?>administrator/page/add"
				method="post"
				enctype="multipart/form-data"
			>
				<div class="form-group">
					<label for="title">Judul Halaman</label>
					<input
						type="text"
						class="form-control"
						id="title"
						name="title"
						required
						autocomplete="off"
					/>
				</div>
				<div class="form-group">
					<label for="slug">Slug Halaman</label>
					<input
						type="text"
						class="form-control"
						id="slug"
						name="slug"
						required
						autocomplete="off"
					/>
					<small class="text-muted">Gunakan tanda - jika lebih dari 1 kata. Contoh: about-us</small>
				</div>
				<div class="form-group">
					<label for="description">Deskripsi</label>
					<textarea name="description" id="description" cols="30" rows="10"></textarea>
				</div>
				<button type="submit" class="btn mr-2 btn-primary">Tambah Halaman</button>
				<a
					href="<?= base_url(); ?>administrator/pages"
					class="btn px-4 btn-danger"
					>Batal</a
				>
			</form>
		</div>
	</div>
</div>
<!-- /.container-fluid -->
