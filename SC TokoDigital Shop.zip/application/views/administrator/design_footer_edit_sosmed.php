<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <a href="<?= base_url(); ?>administrator/design/footer" class="text-secondary">Tentang Kami</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="text-primary">Sosial Media</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/payment" class="text-secondary">Logo Pembayaran</a>
        </div>
        <form action="<?= base_url(); ?>administrator/design/footer/sosmed/<?= $sosmed['id'] ?>" method="post">
            <br>
            <div class="form-group">
                <label for="name">Jenis Sosmed</label>
                <input type="text" class="form-control" id="name" name="name" required autocomplete="off" value="<?= $sosmed['name']; ?>">
                <small class="text-muted">Contoh: Facebook, Twitter</small>
            </div>
            <div class="form-group">
                <label for="icon">Icon Sosmed</label>
                <input type="text" class="form-control" id="icon" name="icon" required autocomplete="off" value="<?= $sosmed['icon']; ?>">
                <small class="text-muted">Buka link ini <a href="https://fontawesome.com/icons" target="_blank">fontawesome</a> lalu cari nama sosmed. Misal icon untuk Facebook adalah facebook-f</small>
            </div>
            <div class="form-group">
                <label for="link">Link atau URL</label>
                <input type="text" class="form-control" id="link" name="link" required autocomplete="off" value="<?= $sosmed['link']; ?>">
                <small class="text-muted">Misal: https://facebook.com/namapengguna</small>
            </div>
            <button type="submit" class="btn px-3 mr-2 btn-primary">SIMPAN</button>
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="btn btn-danger px-3">BATAL</a>
        </form>
    </div>
</div>