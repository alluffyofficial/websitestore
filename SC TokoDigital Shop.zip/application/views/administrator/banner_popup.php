<?php echo $this->session->flashdata('upload'); ?>

<div class="container-fluid">
  <h1 class="h4 mb-2 text-gray-800 mb-4">Banner Pop up</h1>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <?php if ($banner->num_rows() < 1) { ?>
      <div class="card-header py-3">
        <a href="<?= base_url(); ?>administrator/banner-popup/add" class="btn btn-primary">Buat Banner</a>
      </div>
    <?php } ?>
    <div class="card-body">
      <?php if ($banner->num_rows() > 0) { ?>
        <table class="table table-bordered">
          <tr>
            <th>Gambar</th>
            <th>Delay</th>
            <th>URL</th>
            <th class="text-center">Aksi</th>
          </tr>
          <?php foreach ($banner->result_array() as $d) : ?>
            <tr>
              <td><img style="width: 250px" src="<?= base_url(); ?>assets/images/banner/<?= $d['img']; ?>" alt=""></td>
              <td><?= $d['delay']; ?> detik</td>
              <td><?= $d['url']; ?></td>
              <td class="text-center">
                <a href="<?= base_url(); ?>administrator/delete_banner_popup/<?= $d['id']; ?>" onclick="return confirm('Yakin ingin menghapus banner pop up ini?')" class="text-danger h5"><i class="fa fa-trash-alt"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php } else { ?>
        <div class="alert alert-warning">Belum ada banner popup</div>
      <?php } ?>
    </div>
  </div>
</div>