<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <?php echo $this->session->flashdata('failed'); ?>
        <form action="<?= base_url(); ?>administrator/add_banner_setting_post" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="img">Gambar Banner</label>
                <input type="file" name="img" id="img" class="form-control-file">
                <small class="text-muted">Pastikan gambar berukuran maksimal 2mb, berformat png, jpg, jpeg. Dan berukuran 3000x1030px</small>
            </div>
            <div class="form-group">
                <label for="url">URL (opsional)</label>
                <input type="text" class="form-control" name="url" autocomplete="off" id="url">
                <small class="text-muted">Jika banner di klik maka akan mengarah ke link/url diatas. Misal: https://domain.com/p/produk-keren</small>
            </div>
            <button type="submit" class="btn mr-2 px-3 btn-primary">TAMBAH</button>
            <a href="<?= base_url(); ?>administrator/design/banner" class="btn btn-danger px-3">BATAL</a>
        </form>
    </div>
</div>