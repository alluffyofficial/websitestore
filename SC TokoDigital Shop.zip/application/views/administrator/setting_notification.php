<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan Notifikasi</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/setting/account"><i class="uil-user-circle"></i> Akun</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/setting/payment"><i class="uil-usd-circle"></i> Pembayaran</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/setting/notification"><i class="uil-comment-alt-dots"></i> Notifikasi</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/setting/pixel"><i class="uil-facebook"></i> Pixel</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/setting/seo"><i class="uil-google"></i> SEO</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <!-- <a href="<?= base_url(); ?>administrator/setting/notification" class="text-primary">Order Baru</a> |  -->
            <a href="<?= base_url(); ?>administrator/setting/notification/follow-up" class="text-secondary">Follow up</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/confirmation" class="text-secondary">Konfirmasi</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/delivery" class="text-secondary">Pengiriman</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/finish" class="text-secondary">Order Selesai</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/cancel" class="text-secondary">Batal</a>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group mt-3">
                    <div class="top tools-text-editor">
                        <button data-role="bold" class="btn btn-outline-secondary btn-sm font-weight-bold">B</button>
                        <button data-role="italic" class="btn btn-outline-secondary btn-sm font-italic">I</button>
                        <button data-role="strikeThrough" class="btn btn-outline-secondary btn-sm" style="text-decoration: line-through;">S</button>
                        <small class="text-secondary"></small>
                    </div>
                    <div class="form-control div-hijrah-to-textarea" id="contentSettingNotificationNewOrderPage" style="" contenteditable><?= $notification['new_order'] ?></div>
                </div>
                <button id="btnSaveSettingNotificationNewOrderPage" class="btn mt-2 btn-primary px-4">Simpan Pengaturan</button>
            </div>
        </div>
    </div>
</div>