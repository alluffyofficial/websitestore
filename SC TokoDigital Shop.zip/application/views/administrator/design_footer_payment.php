<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <a href="<?= base_url(); ?>administrator/design/footer" class="text-secondary">Tentang Kami</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="text-secondary">Sosial Media</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/payment" class="text-primary">Logo Pembayaran</a>
        </div>
        <form action="<?= base_url(); ?>administrator/design/footer/payment" method="post">
            <input type="hidden" name="bank" value="ok">
            <div class="form-group mt-3">
                <label>Pilih Pembayaran</label>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" name="bca" <?= $logo['bca'] == 1 ? "checked" : NULL ?> class="custom-control-input" id="bca">
                            <label class="custom-control-label" for="bca">BCA</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['mandiri'] == 1 ? "checked" : NULL ?> name="mandiri" class="custom-control-input" id="mandiri">
                            <label class="custom-control-label" for="mandiri">MANDIRI</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['bri'] == 1 ? "checked" : NULL ?> name="bri" class="custom-control-input" id="bri">
                            <label class="custom-control-label" for="bri">BRI</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['bni'] == 1 ? "checked" : NULL ?> name="bni" class="custom-control-input" id="bni">
                            <label class="custom-control-label" for="bni">BNI</label>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['bcas'] == 1 ? "checked" : NULL ?> name="bcas" class="custom-control-input" id="bcas">
                            <label class="custom-control-label" for="bcas">BCA SYARIAH</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['mandiris'] == 1 ? "checked" : NULL ?> name="mandiris" class="custom-control-input" id="mandiris">
                            <label class="custom-control-label" for="mandiris">MANDIRI SYARIAH</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['bris'] == 1 ? "checked" : NULL ?> name="bris" class="custom-control-input" id="bris">
                            <label class="custom-control-label" for="bris">BRI SYARIAH</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['bnis'] == 1 ? "checked" : NULL ?> name="bnis" class="custom-control-input" id="bnis">
                            <label class="custom-control-label" for="bnis">BNI SYARIAH</label>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['jenius'] == 1 ? "checked" : NULL ?> name="jenius" class="custom-control-input" id="jenius">
                            <label class="custom-control-label" for="jenius">JENIUS</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['ovo'] == 1 ? "checked" : NULL ?> name="ovo" class="custom-control-input" id="ovo">
                            <label class="custom-control-label" for="ovo">OVO</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['dana'] == 1 ? "checked" : NULL ?> name="dana" class="custom-control-input" id="dana">
                            <label class="custom-control-label" for="dana">DANA</label>
                        </div>
                        <div class="custom-control mb-2 custom-switch">
                            <input type="checkbox" <?= $logo['gopay'] == 1 ? "checked" : NULL ?> name="gopay" class="custom-control-input" id="gopay">
                            <label class="custom-control-label" for="gopay">GOPAY</label>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-3">SIMPAN PENGATURAN</button>
        </form>
    </div>
</div>