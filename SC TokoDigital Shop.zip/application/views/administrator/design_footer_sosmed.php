<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <a href="<?= base_url(); ?>administrator/design/footer" class="text-secondary">Tentang Kami</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="text-primary">Sosial Media</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/payment" class="text-secondary">Logo Pembayaran</a>
        </div>
        <a href="<?= base_url(); ?>administrator/design/footer/sosmed/add" class="btn btn-primary mt-3 px-3">TAMBAH</a>
        <?php if ($sosmed->num_rows() > 0) { ?>
            <table class="table mt-2 table-bordered">
                <tr>
                    <th>Jenis Sosmed</th>
                    <th>Icon</th>
                    <th>Link atau URL</th>
                    <th>Aksi</th>
                </tr>
                <?php foreach ($sosmed->result_array() as $d) : ?>
                    <tr>
                        <td><?= $d['name']; ?></td>
                        <td class="text-center"> <i class="fab fa-<?= $d['icon']; ?>"></i> </td>
                        <td><?= $d['link']; ?></td>
                        <td style="width: 100px">
                            <a href="<?= base_url(); ?>administrator/design/footer/sosmed/<?= $d['id']; ?>" class="btn btn-sm btn-info"><i class="fa fa-pen"></i></a>
                            <a href="<?= base_url(); ?>administrator/delete_sosmed/<?= $d['id']; ?>" onclick="return confirm('Yakin ingin menghapus sosmed ini?')" class="btn btn-sm btn-danger"><i class="fa fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php } else { ?>
            <div class="alert mt-3 alert-warning">Belum ada akun sosmed.</div>
        <?php } ?>
    </div>
</div>