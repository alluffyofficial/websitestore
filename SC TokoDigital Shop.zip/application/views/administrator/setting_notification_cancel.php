<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan Notifikasi</h1>

<div class="card">
    <div class="card-body">
        <?php include 'setting_menu.php'; ?>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <!-- <a href="<?= base_url(); ?>administrator/setting/notification" class="text-secondary">Order Baru</a> |  -->
            <a href="<?= base_url(); ?>administrator/setting/notification/follow-up" class="text-secondary">Follow up</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/confirmation" class="text-secondary">Konfirmasi</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/finish" class="text-secondary">Order Selesai</a> |
            <a href="<?= base_url(); ?>administrator/setting/notification/cancel" class="text-primary">Batal</a>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group mt-3">
                    <div class="top tools-text-editor">
                        <button data-role="bold" class="btn btn-outline-secondary btn-sm font-weight-bold">B</button>
                        <button data-role="italic" class="btn btn-outline-secondary btn-sm font-italic">I</button>
                        <button data-role="strikeThrough" class="btn btn-outline-secondary btn-sm" style="text-decoration: line-through;">S</button>
                        <small class="text-secondary"></small>
                    </div>
                    <div class="form-control div-hijrah-to-textarea" id="contentSettingNotificationCancelPage" style="" contenteditable><?= $notification['cancel'] ?></div>
                </div>
                <button id="btnSaveSettingNotificationCancelPage" class="btn mt-2 btn-primary px-4">Simpan Pengaturan</button>
            </div>
        </div>
    </div>
</div>