<?php echo $this->session->flashdata('upload'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<h1 class="h4 mb-2 text-gray-800 mb-4">Edit Produk</h1>

	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-body">
			<?php echo $this->session->flashdata('failed'); ?>
			<form action="<?= base_url(); ?>administrator/product/<?= $product['productId']; ?>/edit" method="post" enctype="multipart/form-data">
				<div class="form-row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="title">Nama Produk</label>
							<input type="text" class="form-control" id="title" name="title" autocomplete="off" required value="<?= $product['title']; ?>" />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="cat">Kategori</label>
							<select class="form-control" id="cat" name="category">
								<?php foreach ($categories->result_array() as $c) : ?>
									<option <?= $c['id'] == $product['category'] ? "selected" : null ?> value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
				<div class="form-row">
                    <div class="col-md-6">		
                        <div class="form-group mt-1">
                            <label for="img">Foto</label><br>
							<?php if ($product['img'] != "") { ?>
								<?php $showimg = "";
								if ($product['ex_img'] == 1) {
									$showimg = $product['img'];
								} else {
									if ($product['img_real'] == "") {
										$showimg = base_url() . 'assets/images/product/' . $product['img'];
									} else {
										$showimg = base_url() . 'assets/images/product/' . $product['img_real'];
									}
								} ?>
								<img src="<?= $showimg; ?>" alt="foto produk" width="130">
								<a href="<?= base_url(); ?>administrator/delete_image/<?= $product['productId']; ?>" onclick="return confirm('Yakin ingin menghapus gambar?');" class="btn btn-sm btn-danger">hapus</a>
							<?php } ?>
							<input type="file" class="form-control-file mt-1" id="img" name="img" autocomplete="off" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="video_yt">URL Video Youtube</label>
							<input type="text" id="video_yt" value="<?= $product['video_yt'] ?>" name="video_yt" class="form-control" autocomplete="off">
                        </div>
                    </div>
                </div>
				<div class="form-group">
					<label for="description">Deskripsi</label>
					<textarea class="form-control" id="description" name="description" rows="7"><?= $product['description']; ?></textarea>
				</div>
				<div class="form-row">
					<div class="col-lg-6">
						<div class="form-group">
							<label for="variant1">Varian 1</label>
							<input type="text" class="form-control" value="<?= $product['variant1'] ?>" id="variant1" name="variant1" placeholder="Nama Varian" autocomplete="off">
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-lg-6">
									<input type="text" class="form-control" value="<?= $product['variant1_price'] ?>" name="variant1_price" placeholder="Harga" required>
								</div>
								<div class="col-lg-6">
									<div class="input-group">
										<input type="text" class="form-control" name="variant1_discount" value="<?= $product['variant1_discount'] ?>" placeholder="Diskon">
										<div class="input-group-append">
											<span class="input-group-text">%</span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group" id="wrapperPointVariant1Container">
							<?php $nourut = 1000;
							foreach ($variant1_point->result_array() as $data) : ?>
								<div class="row mb-2 row-point-variant1-<?= $nourut ?>">
									<div class="col-lg-11">
										<input type="text" class="form-control" placeholder="Point" name="variant1_point[]" value="<?= $data['point'] ?>" autocomplete="off" />
									</div>
									<div class="col-lg-1">
										<i onclick="deleteVariantPointAddProduct('1', '<?= $nourut ?>')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
									</div>
								</div>
							<?php $nourut++;
							endforeach; ?>
						</div>
						<button type="button" id="btnAddPointVariant1WhenAddProduct" class="btn btn-outline-success"><i class="fa fa-plus"></i> Tambah</button>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label for="variant2">Varian 2</label>
							<input type="text" class="form-control" value="<?= $product['variant2'] ?>" id="variant2" name="variant2" placeholder="Nama Varian" autocomplete="off">
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-lg-6">
									<input type="text" class="form-control" value="<?= $product['variant2_price'] ?>" name="variant2_price" placeholder="Harga">
								</div>
								<div class="col-lg-6">
									<div class="input-group">
										<input type="text" class="form-control" name="variant2_discount" value="<?= $product['variant2_discount'] ?>" placeholder="Diskon">
										<div class="input-group-append">
											<span class="input-group-text">%</span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group" id="wrapperPointVariant2Container">
							<?php $nourut = 1000;
							foreach ($variant2_point->result_array() as $data) : ?>
								<div class="row mb-2 row-point-variant2-<?= $nourut ?>">
									<div class="col-lg-11">
										<input type="text" class="form-control" placeholder="Point" name="variant2_point[]" value="<?= $data['point'] ?>" autocomplete="off" />
									</div>
									<div class="col-lg-1">
										<i onclick="deleteVariantPointAddProduct('2', '<?= $nourut ?>')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
									</div>
								</div>
							<?php $nourut++;
							endforeach; ?>
						</div>
						<button type="button" id="btnAddPointVariant2WhenAddProduct" class="btn btn-outline-success"><i class="fa fa-plus"></i> Tambah</button>
					</div>
				</div>

				<div class="form-row mt-3 mb-3">
					<div class="col-lg-6">
						<div class="form-group">
							<label for="publish">Status</label>
							<select class="form-control" id="publish" name="publish">
								<option <?= $product['publish'] == 1 ? "selected" : null ?> value="1">Publish</option>
								<option <?= $product['publish'] == 2 ? "selected" : null ?> value="2">Draft</option>
							</select>
						</div>
					</div>
				</div>
				<button type="submit" class="btn mr-3 px-4 btn-primary">SIMPAN PRODUK</button>
				<a href="<?= base_url(); ?>administrator/products" class="btn px-4 btn-danger">BATAL</a>
			</form>
		</div>
	</div>
</div>
<!-- /.container-fluid -->
<script src="<?= base_url(); ?>assets/admin/libs/jquery/jquery.min.js"></script>
<script>
	let globalWrapperVariant1 = 1;
	$("#btnAddPointVariant1WhenAddProduct").on("click", function() {
		$("#wrapperPointVariant1Container").append(`
			<div class="row row-point-variant1-${globalWrapperVariant1} mt-2">
				<div class="col-lg-11">
					<input type="text" class="form-control" placeholder="Point" name="variant1_point[]" autocomplete="off" />
				</div>
				<div class="col-lg-1">
					<i onclick="deleteVariantPointAddProduct('1', '${globalWrapperVariant1}')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
				</div>
			</div>
		`);
		globalWrapperVariant1++;
	})

	let globalWrapperVariant2 = 1;
	$("#btnAddPointVariant2WhenAddProduct").on("click", function() {
		$("#wrapperPointVariant2Container").append(`
			<div class="row row-point-variant2-${globalWrapperVariant2} mt-2">
				<div class="col-lg-11">
					<input type="text" class="form-control" placeholder="Point" name="variant2_point[]" autocomplete="off" />
				</div>
				<div class="col-lg-1">
					<i onclick="deleteVariantPointAddProduct('2', '${globalWrapperVariant2}')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
				</div>
			</div>
		`);
		globalWrapperVariant2++;
	})

	function deleteVariantPointAddProduct(type, id) {
		$(`.row-point-variant${type}-${id}`).remove();
	}
</script>