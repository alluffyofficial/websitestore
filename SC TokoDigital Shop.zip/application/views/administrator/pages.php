<?php echo $this->session->flashdata('upload'); ?>

<h1 class="h4 mb-2 text-gray-800">Halaman</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
	<div class="card-body py-3">
		<a
			href="<?= base_url(); ?>administrator/page/add"
			class="btn btn-primary"
			>Tambah</a
		>
	</div>
	<div class="card-body">
		<?php echo $this->session->flashdata('failed'); ?> 
		<?php if($pages->num_rows() > 0){ ?>
		<div class="table-responsive">
			<table
				class="table table-bordered"
				id="dataTable"
				width="100%"
				cellspacing="0"
			>
				<thead>
					<tr>
						<th class="text-center" width="60">No.</th>
						<th>Judul Halaman</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tfoot></tfoot>
				<tbody class="data-content">
					<?php $no = 1 ?>
					<?php foreach($pages->result_array() as $data): ?>
					<tr>
						<td class="text-center"><?= $no ?></td>
						<td><?= $data['title']; ?></td>
						<td style="width: 120px">
							<a target="_blank" href="<?= base_url() . $data['slug']; ?>"><i class="fa text-success fa-eye h5 mr-3"></i></a>
							<a href="<?= base_url() ;?>administrator/page/<?= $data['id']; ?>/edit" class="h5 mr-3 text-info"><i class="fa fa-pen"></i></a>
							<a href="<?= base_url() ;?>administrator/delete_page/<?= $data['id']; ?>" onclick="return confirm('Yakin ingin menghapus halaman?');" class="h5 text-danger"><i class="fa fa-trash-alt"></i></a>
						</td>
					</tr>
					<?php $no++ ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php }else{ ?>
		<div class="alert alert-warning" role="alert">
			Opss, halaman masih kosong, yuk tambah sekarang.
		</div>
		<?php } ?>
	</div>
</div>