<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Pengaturan Facebook Pixel</h1>

<div class="card">
    <div class="card-body">
        <?php include 'setting_menu.php'; ?>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/setting/pixel" method="post">
            <div class="form-group mt-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="hidden" name="helper" value="true">
                            <label for="idPixel">Masukan ID Pixel</label>
                            <input type="text" name="idPixel" id="idPixel" autocomplete="off" class="form-control" value="<?= $setting['id_pixel']; ?>">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary px-4">Simpan Pengaturan</button>
            </div>
        </form>
    </div>
</div>