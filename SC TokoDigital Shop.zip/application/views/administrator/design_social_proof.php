<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
    <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <form action="<?= base_url(); ?>administrator/design/social-prof" method="post">
        <?php echo $this->session->flashdata('failed'); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <?php if($general['social_proof_status'] == 1){ ?>
                                <input type="checkbox" checked class="custom-control-input" id="socialProofStatusDesign">
                            <?php }else{ ?>
                                <input type="checkbox" class="custom-control-input" id="socialProofStatusDesign">
                            <?php } ?>
                            <label class="custom-control-label" for="socialProofStatusDesign">Aktifkan Social Proof</label>
                        </div>
                        <small class="text-success" style="display: none" id="msgSocialProofStatusDesign">Berhasil mengubah</small>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="pause" class="d-block">Jeda antar notifikasi muncul</label>
                            <input type="number" id="pause" name="pause" class="form-control" placeholder="Dalam satuan detik" autocomplete="off" value="<?= $general['pause_social_proof'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="time" class="d-block">Lama waktu notifikasi muncul</label>
                            <input type="number" placeholder="Dalam satuan detik" autocomplete="off" name="time" required value="<?= $general['time_social_proof'] ?>" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary px-3">Simpan Pengaturan</button>
        </form>
    </div>
</div>