<?php echo $this->session->flashdata('upload'); ?>
<h1 class="h4 mb-2">Tampilan</h1>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/header">Header</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/menu">Menu</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/banner">Banner</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/chat-help">Chat Help</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-secondary nav-link" href="<?= base_url(); ?>administrator/design/social-prof">Social Proof</a>
            </li>
            <li class="nav-item">
                <a class="flex-sm-fill text-primary nav-link" href="<?= base_url(); ?>administrator/design/footer">Footer</a>
            </li>
        </ul>
    </div>
    <hr class="mt-0 mb-0">
    <div class="card-body">
        <div class="top">
            <a href="<?= base_url(); ?>administrator/design/footer" class="text-primary">Tentang Kami</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/sosmed" class="text-secondary">Sosial Media</a> |
            <a href="<?= base_url(); ?>administrator/design/footer/payment" class="text-secondary">Logo Pembayaran</a>
        </div>
        <form action="<?= base_url(); ?>administrator/design/footer" method="post">
            <?php echo $this->session->flashdata('failed'); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group mt-3">
                        <label for="about">Tentang Toko</label>
                        <textarea name="about" id="about" rows="5" class="form-control"><?= $setting['short_desc']; ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary px-3">Simpan Pengaturan</button>
                </div>
            </div>
        </form>
    </div>
</div>