<?php
  header('Content-type: application/xml; charset="ISO-8859-1"',true);  
?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc><?= base_url(); ?></loc>
    <lastmod><?= date('d-m-Y H:i:s') ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.1</priority>
  </url>
  <url>
    <loc><?= base_url(); ?>tracking</loc>
    <lastmod><?= date('d-m-Y H:i:s') ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.1</priority>
  </url>
  <url>
    <loc><?= base_url(); ?>products</loc>
    <lastmod><?= date('d-m-Y H:i:s') ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.1</priority>
  </url>
  <url>
    <loc><?= base_url(); ?>best</loc>
    <lastmod><?= date('d-m-Y H:i:s') ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.1</priority>
  </url>
  <?php foreach($categories->result_array() as $c){ ?>
    <url>
        <loc><?= base_url(); ?>c/<?= $c['slug']; ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.1</priority>
    </url>
  <?php } ?>
  <?php foreach($products->result_array() as $p){ ?>
    <url>
        <loc><?= base_url(); ?>p/<?= $p['slug']; ?></loc>
        <lastmod><?= $p['date_submit']; ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.1</priority>
    </url>
  <?php } ?>
  <?php foreach($pages->result_array() as $p){ ?>
    <url>
        <loc><?= base_url() . $p['slug']; ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.1</priority>
    </url>
  <?php } ?>
</urlset>