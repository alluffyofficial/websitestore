<style>
    div.wrapper div.top div.main-top div.ket button.item-option {
        border: 1px solid <?= $this->Settings_model->general()['navbar_color']; ?>;
    }

    div.wrapper div.top div.main-top div.ket button.btn-for-addcart {
        background-color: <?= $this->Settings_model->general()['btncolor']; ?>
    }

    div.wrapper div.top div.main-top div.ket button.btn-for-addcart:hover {
        background-color: #353535;
    }

    .hov:hover {
        background-color: #F6F6F6;
    }

    .variant-button button.active {
        background-color: <?= $this->Settings_model->general()['btncolor']; ?>;
        border: 1px solid <?= $this->Settings_model->general()['btncolor']; ?>;
    }

    button.btn-add-rating {
        background-color: <?= $this->Settings_model->general()['btncolor']; ?>;
    }

    button.btn-add-rating:hover {
        background-color: #353535;
    }
</style>
<?php echo $this->session->flashdata('sweetalert'); ?>
<?php function getIdYoutube($url)
{
    preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url, $matches);
    return $matches;
} ?>
<?php include __DIR__ . '/../templates/star.php' ?>
<?php if ($this->Settings_model->general()['social_proof_status'] == 1) { ?>
  <?php $noooo = 1;
  foreach ($invoice->result_array() as $in) : ?>
    <input type="hidden" id="numberOfInvoiceTotalHomePage" value="<?= $invoice->num_rows(); ?>">
    <div class="social-proof" id="socialProofId-<?= $noooo; ?>">
      <div class="main">
        <?php $product_buy = $this->db->get_where('transaction', ['id_invoice' => $in['invoice_code']])->row_array();
        $product_real = $this->db->get_where('products', ['slug' => $product_buy['slug']])->row_array(); ?>
        <?php if ($product_real['img'] == "") { ?>
          <img src="<?= getThumbnail($product_real['video_yt']); ?>" alt="<?= $product_real['title']; ?>">
        <?php } else { ?>
          <img alt="<?= $product_real['title']; ?>" src="<?= $product_real['ex_img'] == 1 ? $product_real['img'] : base_url() . 'assets/images/product/' . $product_real['img']; ?>">
        <?php } ?>
        <div class="text">
          <p><span class="font-bold"><?= strlen($in['name']) > 15 ? substr($in['name'], 0, 15) . '..' : $in['name']; ?></span> membeli
          <p class="font-bold product_name"><?= $product_real['title'] ?></p>
          </p>
          <span class="verified"><img src="<?= base_url(); ?>assets/images/icon/verified.png" alt="verified icon"> Verified by <span class="app_name"><?= $this->Settings_model->general()['app_name']; ?></span></span>
        </div>
      </div>
    </div>
  <?php $noooo++;
  endforeach; ?>
<?php } ?>


<div class="wrapper">
    <script>
        fbq('track', 'ViewContent');
    </script>
    <?php $setting = $this->db->get('settings')->row_array(); ?>
    <div class="top">
        <div class="main-top">
            <div class="img">
                <?php if ($product['img'] == "") { ?>
                    <iframe src="https://www.youtube.com/embed/<?= getIdYoutube($product['video_yt'])[0]; ?>" title="<?= $product['title']; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <?php } else { ?>
                    <?php $showimg = "";
                    if ($product['ex_img'] == 1) {
                        $showimg = $product['img'];
                    } else {
                        if ($product['img_real'] == "") {
                            $showimg = base_url() . 'assets/images/product/' . $product['img'];
                        } else {
                            $showimg = base_url() . 'assets/images/product/' . $product['img_real'];
                        }
                    } ?>
                    <a href="<?= $showimg; ?>" data-lightbox="lightbox-img">
                        <div class="icon-zoom-image"><i class="fa shadow-sm fa-search-plus"></i></div>
                        <img style="cursor: pointer;" alt="<?= $product['title']; ?>" src="<?= $product['ex_img'] == 1 ? $product['img'] : base_url() . 'assets/images/product/' . $product['img']; ?>" class="jumbo-thumb">
                    </a>
                <?php } ?>
                
            </div>
            <div class="ket">
                <!--Judul-->
                <h1 class="title"><?= $product['title']; ?></h1>
                <div class="variant-button">
                    <button class="<?= $product['variant2'] == "" ? "variant-button-cursor-normal" : "variant-button-1 active" ?>" onclick="changeVariant('1')"><?= $product['variant1'] ?></button>
                    <?php if ($product['variant2'] != "") { ?>
                        <button class="variant-button-2" onclick="changeVariant('2')"><?= $product['variant2'] ?></button>
                    <?php } ?>
                </div>
                <div class="price-variant-1">
                    <?php if ($product['variant1_discount'] == 0) { ?>
                        <h4 class="price mb-0 real-price-this-product">Rp. <?= str_replace(",", ".", number_format($product['variant1_price'])); ?></h4>
                    <?php } else { ?>
                        <div class="price-col mb-0">
                            <?php $diskonnya = ($product['variant1_price'] * $product['variant1_discount']) / 100 ?>
                            <h4 class="price mb-0 changed-price-this-product">Rp. <?= str_replace(",", ".", number_format($product['variant1_price'] - $diskonnya)); ?></h4>
                            <p class="oldPrice mb-0 real-price-this-product">Rp. <span class="linet"><?= str_replace(",", ".", number_format($product['variant1_price'])); ?></span> <span class="badge badge-danger"><?= $product['variant1_discount']; ?>%</span></p>
                        </div>
                    <?php } ?>
                </div>
                <div class="price-variant-2" style="display: none;">
                    <?php if ($product['variant2_discount'] == 0) { ?>
                        <h4 class="price mb-0 real-price-this-product">Rp. <?= str_replace(",", ".", number_format($product['variant2_price'])); ?></h4>
                    <?php } else { ?>
                        <div class="price-col mb-0">
                            <?php $diskonnya = ($product['variant2_price'] * $product['variant2_discount']) / 100 ?>
                            <h4 class="price mb-0 changed-price-this-product">Rp. <?= str_replace(",", ".", number_format($product['variant2_price'] - $diskonnya)); ?></h4>
                            <p class="oldPrice mb-0 real-price-this-product">Rp. <span class="linet"><?= str_replace(",", ".", number_format($product['variant2_price'])); ?></span> <span class="badge badge-danger"><?= $product['variant2_discount']; ?>%</span></p>
                        </div>
                    <?php } ?>
                </div>
                <div class="points points-variant-1">
                    <?php foreach ($variant1->result_array() as $v) : ?>
                        <p class="mb-1"><i class="far fa-check-circle"></i> <?= $v['point'] ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="points points-variant-2" style="display: none;">
                    <?php foreach ($variant2->result_array() as $v) : ?>
                        <p class="mb-1"><i class="far fa-check-circle"></i> <?= $v['point'] ?></p>
                    <?php endforeach; ?>
                </div>
                <button class="btn-for-addcart font-weight-bold" onclick="orderNow()">PESAN SEKARANG</button>
            </div>
        </div>
    </div>
    <div class="top-desc">
        <h4 class="title-desc">Deskripsi Produk</h4>
        <button class="share">
            <i class="fa fa-share-alt"></i> Share
        </button>
        <div class="share-dd">
            <a target="_blank" href="https://facebook.com/share.php?u=<?= base_url(); ?>p/<?= $product['slugP']; ?>" style="color: #3b5998">
                <i class="fab fa-facebook-square"></i>
            </a>
            <a target="_blank" href="https://wa.me?text=<?= base_url(); ?>p/<?= $product['slugP']; ?>" style="color: #03AC0E">
                <i class="fab fa-whatsapp-square"></i>
            </a>
            <a target="_blank" href="https://twitter.com/intent/tweet?url=<?= base_url(); ?>p/<?= $product['slugP']; ?>" style="color: #1da1f2">
                <i class="fab fa-twitter-square"></i>
            </a>
            <a onclick="copyFunction()" style="color: #F1B44C; cursor: pointer;">
                <i class="fas fa-share-alt-square"></i>
            </a>
            <small style="display: none;" class="msgSuccessCopyLink text-success">Berhasil menyalin link</small>
        </div>
        <input style="position: absolute;  left: -1000%;" type="text" value="<?= base_url(); ?>p/<?= $product['slugP']; ?>" id="inputForTextSlug">
        <script>
            function copyFunction() {
                var copyText = document.getElementById("inputForTextSlug");
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                document.execCommand("copy");
                document.querySelector(".msgSuccessCopyLink").style.display = "block";
                setTimeout(function() {
                    document.querySelector(".msgSuccessCopyLink").style.display = "none";
                }, 1500);
            }
        </script>
    </div>
    <hr>
    <div class="description">
        <?php
        $descChange = str_replace('<figure class="media"><oembed url="https://www.youtube.com/watch?v=', '<iframe src="https://www.youtube.com/embed/', $product['description']);
        $descChange = str_replace('"></oembed></figure>', '"></iframe>', $descChange);
        ?>
        <?= nl2br($descChange); ?>
    </div>
    <hr>
    <div class="rating">
        <div class="top-rating mb-3 mt-3">
            <h4 class="title">Review Pelanggan</h4>
            <span><i class="fa fa-chevron-down"></i></span>
        </div>
        <div class="main-rating mt-2">
            <?php foreach ($rating->result_array() as $data) : ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <p class="mb-1"><strong><?= $data['name'] ?></strong></p>
                        <div class="rating-star-view"><?= rattingStars(round($data['star'], 1)); ?></div>
                        <p class="mb-0 text-secondary">"<?= $data['review'] ?>"</p>
                    </div>
                </div>
            <?php endforeach; ?>
            <?= $this->pagination->create_links(); ?>
        <div class="input-rating">
            <div class="card">
                <div class="card-header">
                    <p class="mb-0">Berikan Rating</p>
                </div>
                <div class="card-body">
                    <form action="<?= base_url(); ?>products/save_rating/<?= $product['productId']; ?>" method="post">
                        <div class="form-group">
                            Pilih Rating: <div class="starrr"></div>
                            <input type="hidden" name="rating-star" class="starrr-rating-star-count">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Nama Lengkap" autocomplete="off" required name="rating-name">
                        </div>
                        <div class="form-group">
                            <textarea name="rating-review" rows="3" class="form-control" required placeholder="Tulis Review"></textarea>
                        </div>
                        <button class="btn text-light px-4 btn-add-rating">Submit</button>
                    </form>
                </div>
            </div>
        </div>
        
        </div>
    </div>
    <hr>
    <?php if ($related->num_rows() > 0) { ?>
        <div class="product-wrapper best-product">
            <br>
            <h2 class="title">Produk Terkait</h2>
            <a href="<?= base_url(); ?>c/<?= $product['cSlug'] ?>" class="float-right mt-2">Lihat semua</a>
            <br><br>
            <div class="main-product">
                <?php foreach ($related->result_array() as $p) : ?>
                    <div>
                        <a href="<?= base_url(); ?>p/<?= $p['slug']; ?>">
                            <div class="item-product hov">
                                <?php if ($p['img'] == "") { ?>
                                    <div class="aspect-ratio-thumb-youtube">
                                        <img src="<?= getThumbnail($p['video_yt']); ?>" class="card-img-top" alt="<?= $p['title']; ?>">
                                    </div>
                                <?php } else { ?>
                                    <img alt="<?= $p['title']; ?>" src="<?= $p['ex_img'] == 1 ? $p['img'] : base_url() . 'assets/images/product/' . $p['img']; ?>" class="card-img-top">
                                <?php } ?>
                                <div class="card-body">
                                    <?php if ($p['variant1_discount'] == 0) { ?>
                                        <p class="card-text line-3 mb-0"><?= $p['title']; ?></p>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['variant1_price'])); ?></p>
                                    <?php } else { ?>
                                        <p class="card-text mb-0"><?= $p['title']; ?></p>
                                        <p class="oldPrice mb-0">Rp. <span><?= str_replace(",", ".", number_format($p['variant1_price'])); ?></span> <small class="badge badge-danger"><?= $p['variant1_discount']; ?>%</small></p>
                                        <?php $diskonnya = ($p['variant1_price'] * $p['variant1_discount']) / 100 ?>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['variant1_price'] - $diskonnya)); ?></p>
                                    <?php } ?>
                                    <div class="stars-rating">
                                        <?php $starsRating = $this->Products_model->rowRatingByProduct($p['id']); ?>
                                        <?= rattingStars(round($starsRating, 1)) ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php } ?>
</div>

<?php if ($product['img'] != "") { ?>
    <?php $showimg = "";
    if ($product['ex_img'] == 1) {
        $showimg = $product['img'];
    } else {
        if ($product['img_real'] == "") {
            $showimg = base_url() . 'assets/images/product/' . $product['img'];
        } else {
            $showimg = base_url() . 'assets/images/product/' . $product['img_real'];
        }
    } ?>
    <div class="modal fade" id="modalShowImageProduct" tabindex="-1" aria-labelledby="modalShowImageProductLabel" aria-hidden="true">
        <div class="modal-dialog-img modal-dialog-centered modal-xl">
            <div class="modal-content-img">
                <img src="<?= $showimg; ?>" alt="">
            </div>
        </div>
    </div>
<?php } ?>

<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script>
    let globalVariantType = 1;

    function changeVariant(id) {
        globalVariantType = id;
        $(".variant-button button").removeClass("active");
        $(`button.variant-button-${id}`).addClass("active");
        if (id == 1) {
            $(".price-variant-2").hide();
            $(".price-variant-1").show();
            $(".points-variant-2").hide();
            $(".points-variant-1").show();
        } else {
            $(".price-variant-1").hide();
            $(".price-variant-2").show();
            $(".points-variant-1").hide();
            $(".points-variant-2").show();
        }
    }

    function addCart() {
        $.ajax({
            url: "<?= base_url(); ?>cart/add_to_cart",
            type: "post",
            data: {
                id: <?= $product['productId']; ?>,
                qty: $("#qtyProduct").val()
            },
            success: function(data) {
                $(".navbar-cart-inform").html(`<i class="fa fa-shopping-cart"></i> Keranjang(<?= count($this->cart->contents()) + 1; ?>)`);
                swal({
                        title: "Berhasil Ditambah ke Keranjang",
                        text: `<?= $product['title']; ?>`,
                        icon: "success",
                        buttons: true,
                        buttons: ["Lanjut Belanja", "Lihat Keranjang"],
                    })
                    .then((cart) => {
                        if (cart) {
                            location.href = "<?= base_url(); ?>cart"
                        }
                    });
            }
        })
    }

    // slider product
    const containerImgProduct = document.querySelector("div.wrapper div.top div.main-top div.img");
    const jumboImgProduct = document.querySelector("div.wrapper div.top div.main-top div.img img.jumbo-thumb");
    const jumboHrefImgProduct = document.querySelector("div.wrapper div.top div.main-top div.img a");
    const thumbsImgProduct = document.querySelectorAll("div.wrapper div.top div.main-top div.img div.img-slider img.thumb");

    containerImgProduct.addEventListener('click', function(e) {
        if (e.target.className == 'thumb') {
            jumboImgProduct.src = e.target.src;
            jumboHrefImgProduct.href = e.target.src;

            thumbsImgProduct.forEach(function(thumb) {
                thumb.className = 'thumb';
            })
        }
    })
</script>