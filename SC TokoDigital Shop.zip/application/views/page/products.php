<div class="product-wrapper">
    <div class="title-head">
        <h2 class="title">PRODUK TERBARU</h2>
    </div>
    <div class="core">
        <?php $setting = $this->db->get('settings')->row_array(); ?>
        <div class="main-product">
            <?php if ($products->num_rows() > 0) { ?>
                <div id="bodyForShowProduct">
                    <?php foreach ($products->result_array() as $p) : ?>
                        <a href="<?= base_url(); ?>p/<?= $p['slug']; ?>">
                            <div class="item-product">
                                <img src="<?= $p['ex_img'] == 1 ? $p['img'] : base_url() . 'assets/images/product/' . $p['img']; ?>" class="card-img-top">
                                <div class="card-body">
                                    <?php if ($p['discount'] == 0) { ?>
                                        <p class="card-text line-3 mb-0"><?= $p['title']; ?></p>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['price'])); ?></p>
                                    <?php } else { ?>
                                        <p class="card-text mb-0"><?= $p['title']; ?></p>
                                        <p class="oldPrice mb-0">Rp. <span><?= str_replace(",", ".", number_format($p['price'])); ?></span> <small class="badge badge-danger"><?= $p['discount']; ?>%</small></p>
                                        <?php $diskonnya = ($p['price'] * $p['discount']) / 100 ?>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['price'] - $diskonnya)); ?></p>
                                    <?php } ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <div class="clearfix"></div>
            <?php } else { ?>
                <div class="alert alert-warning">Upss. Tidak ada produk yang dapat ditampilkan</div>
            <?php } ?>
        </div>
        <?php if ($this->db->get('products')->num_rows() > 12) { ?>
            <img src="<?= base_url(); ?>assets/images/icon/loading-v1.gif" alt="loading.." class="loading-animation-load-more">
            <?php $btncolor = $this->Settings_model->general()['btncolor']; ?>
            <button style="border: 1px solid <?= $btncolor; ?>; color: <?= $btncolor; ?>" class="more" id="btnClickLoadMoreProduct">MUAT LEBIH BANYAK</button>
        <?php } ?>
    </div>
</div>