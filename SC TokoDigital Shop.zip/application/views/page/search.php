<?php include __DIR__ . '/../templates/star.php' ?>
<div class="product-wrapper">
    <div class="title-head mt-5 mb-4 ml-2">
        <h2 class="title">Hasil Pencarian: <?= $q ?></h2>
    </div>
    <div class="core">
        <?php $setting = $this->db->get('settings')->row_array(); ?>
        <div class="main-product">
            <?php if ($products->num_rows() > 0) { ?>
                <div id="bodyForShowProduct">
                    <?php foreach ($products->result_array() as $p) : ?>
                        <a href="<?= base_url(); ?>p/<?= $p['slug']; ?>">
                            <div class="item-product">
                                <?php if ($p['img'] == "") { ?>
                                    <div class="aspect-ratio-thumb-youtube">
                                        <img src="<?= getThumbnail($p['video_yt']); ?>" class="card-img-top" alt="<?= $p['title']; ?>">
                                    </div>
                                <?php } else { ?>
                                    <img alt="<?= $p['title']; ?>" src="<?= $p['ex_img'] == 1 ? $p['img'] : base_url() . 'assets/images/product/' . $p['img']; ?>" class="card-img-top">
                                <?php } ?>
                                <div class="card-body">
                                    <?php if ($p['variant1_discount'] == 0) { ?>
                                        <p class="card-text line-3 mb-0"><?= $p['title']; ?></p>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['variant1_price'])); ?></p>
                                    <?php } else { ?>
                                        <p class="card-text mb-0"><?= $p['title']; ?></p>
                                        <p class="oldPrice mb-0">Rp. <span><?= str_replace(",", ".", number_format($p['variant1_price'])); ?></span> <small class="badge badge-danger"><?= $p['variant1_discount']; ?>%</small></p>
                                        <?php $diskonnya = ($p['variant1_price'] * $p['variant1_discount']) / 100 ?>
                                        <p class="newPrice">Rp. <?= str_replace(",", ".", number_format($p['variant1_price'] - $diskonnya)); ?></p>
                                    <?php } ?>
                                    <div class="stars-rating">
                                        <?php $starsRating = $this->Products_model->rowRatingByProduct($p['id']); ?>
                                        <?= rattingStars(round($starsRating, 1)) ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <div class="clearfix"></div>
            <?php } else { ?>
                <div class="alert alert-warning" style="margin-bottom: 200px">Upss. tidak ada hasil dari <?= $q ?></div>
            <?php } ?>
        </div>
    </div>
</div>