<style>
    div.wrapper button.btn-apply-coupon {
        background-color: <?= $this->Settings_model->general()['navbar_color']; ?>;
        width: 150px;
    }

    div.wrapper button.order_now {
        background-color: <?= $this->Settings_model->general()['btncolor']; ?>;
    }

    div.wrapper button.order_now:hover {
        background-color: #454545;
    }
</style>

<div class="top-back">
    <a href="<?= base_url(); ?>" class="text-dark">
        <i class="fa fa-chevron-left"></i>
    </a>
</div>

<div class="wrapper">
    <h6>DETAIL PESANAN</h6>
    <hr>
    <div class="cart">
        <?php foreach ($this->cart->contents() as $item) : ?>
            <div class="item-cart" id="modalCartBodyListItem-<?= $item['rowid']; ?>">
                <img src="<?= $item['img']; ?>" alt="img product" class="thumb-img">
                <div class="text">
                    <h4 class="product-name"><?= $item['name']; ?></h4>
                    <p class="information mb-0"><?= $item['variant'] ?></p>
                    <h5 class="price" id="modalCartPriceProduct-<?= $item['rowid']; ?>">Rp. <?= number_format($item['subtotal'], 0, ",", "."); ?></h5>
                </div>
            </div>
        <?php endforeach; ?>
        <hr>
    </div>
    <form action="<?= base_url(); ?>checkout/go" method="post">
        <div class="form-group">
            <label for="name">Nama</label>
            <input type="text" class="form-control" name="name" required id="name" autocomplete="off">
        </div>
        <div class="form-group">
            <label for="wa">No WhatsApp</label>
            <input type="number" class="form-control" name="wa" required id="wa" autocomplete="off">
        </div>
        <?php if ($setting['payment_feature'] == 1) { ?>
            <input type="text" style="position: fixed; top: -500%;" name="payment-checking" value="" required id="paymentSelectCheckoutPage">
            <div class="form-group">
                <label for="payment">Pilih Pembayaran</label><br>
                <small class="text-danger" style="display: none" id="msgPaymentFirstCheckoutPage">Pilih pembayaran terlebih dahulu.<br></small>
                <?php if ($logo_pay['bca'] == 1) { ?>
                    <?php $bankbca = $this->db->get_where('rekening', ['rekening' => 1])->row_array(); ?>
                    <?php if ($bankbca) { ?>
                        <img onclick="selectPaymentCheckout('1')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-1" src="<?= base_url(); ?>assets/images/payment/bca.png" alt="bank bca">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['mandiri'] == 1) { ?>
                    <?php $bankmandiri = $this->db->get_where('rekening', ['rekening' => 2])->row_array(); ?>
                    <?php if ($bankmandiri) { ?>
                        <img onclick="selectPaymentCheckout('2')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-2" src="<?= base_url(); ?>assets/images/payment/mandiri.png" alt="bank mandiri">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['bri'] == 1) { ?>
                    <?php $bankbri = $this->db->get_where('rekening', ['rekening' => 3])->row_array(); ?>
                    <?php if ($bankbri) { ?>
                        <img onclick="selectPaymentCheckout('3')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-3" src="<?= base_url(); ?>assets/images/payment/bri.png" alt="bank bri">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['bni'] == 1) { ?>
                    <?php $bankbni = $this->db->get_where('rekening', ['rekening' => 4])->row_array(); ?>
                    <?php if ($bankbni) { ?>
                        <img onclick="selectPaymentCheckout('4')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-4" src="<?= base_url(); ?>assets/images/payment/bni.png" alt="bank bni">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['bcas'] == 1) { ?>
                    <?php $bankbcas = $this->db->get_where('rekening', ['rekening' => 5])->row_array(); ?>
                    <?php if ($bankbcas) { ?>
                        <img onclick="selectPaymentCheckout('5')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-5" src="<?= base_url(); ?>assets/images/payment/bcas.png" alt="bank bcas">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['mandiris'] == 1) { ?>
                    <?php $bankmandiris = $this->db->get_where('rekening', ['rekening' => 6])->row_array(); ?>
                    <?php if ($bankmandiris) { ?>
                        <img onclick="selectPaymentCheckout('6')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-6" src="<?= base_url(); ?>assets/images/payment/mandiris.png" alt="bank mandiris">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['bris'] == 1) { ?>
                    <?php $bankbris = $this->db->get_where('rekening', ['rekening' => 7])->row_array(); ?>
                    <?php if ($bankbris) { ?>
                        <img onclick="selectPaymentCheckout('7')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-7" src="<?= base_url(); ?>assets/images/payment/bris.png" alt="bank bris">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['bnis'] == 1) { ?>
                    <?php $bankbnis = $this->db->get_where('rekening', ['rekening' => 8])->row_array(); ?>
                    <?php if ($bankbnis) { ?>
                        <img onclick="selectPaymentCheckout('8')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-8" src="<?= base_url(); ?>assets/images/payment/bnis.png" alt="bank bnis">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['jenius'] == 1) { ?>
                    <?php $bankjenius = $this->db->get_where('rekening', ['rekening' => 9])->row_array(); ?>
                    <?php if ($bankjenius) { ?>
                        <img onclick="selectPaymentCheckout('9')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-9" src="<?= base_url(); ?>assets/images/payment/jenius.png" alt="bank jenius">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['ovo'] == 1) { ?>
                    <?php $bankovo = $this->db->get_where('rekening', ['rekening' => 10])->row_array(); ?>
                    <?php if ($bankovo) { ?>
                        <img onclick="selectPaymentCheckout('10')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-10" src="<?= base_url(); ?>assets/images/payment/ovo.png" alt="bank ovo">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['dana'] == 1) { ?>
                    <?php $bankdana = $this->db->get_where('rekening', ['rekening' => 11])->row_array(); ?>
                    <?php if ($bankdana) { ?>
                        <img onclick="selectPaymentCheckout('11')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-11" src="<?= base_url(); ?>assets/images/payment/dana.png" alt="bank dana">
                    <?php } ?>
                <?php } ?>
                <?php if ($logo_pay['gopay'] == 1) { ?>
                    <?php $bankgopay = $this->db->get_where('rekening', ['rekening' => 12])->row_array(); ?>
                    <?php if ($bankgopay) { ?>
                        <img onclick="selectPaymentCheckout('12')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-12" src="<?= base_url(); ?>assets/images/payment/gopay.png" alt="bank gopay">
                    <?php } ?>
                <?php } ?>
                <?php if ($this->Settings_model->general()['payment_cod_status'] == 1) { ?>
                    <img onclick="selectPaymentCheckout('13')" class="logo-payment logo-payment-checkout-page logo-payment-checkout-13" src="<?= base_url(); ?>assets/images/icon/cod-icon.png" alt="cod">
                <?php } ?>
            </div>
        <?php } ?>
        <?php if ($setting['potongan_feature'] == 1) { ?>
            <div class="form-group mt-4">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="MASUKAN KUPON" id="inputCouponCheckoutPage">
                    <div class="input-group-append">
                        <button class="btn btn-secondary" type="button" id="btnForApplyCouponCheckoutPage">TERAPKAN</button>
                    </div>
                </div>
                <small class="text-danger" id="msgDangerCouponWrongCheckoutPage"></small>
            </div>
        <?php } ?>
        <div class="info">
            <table class="table table-sm table-borderless">
                <tr>
                    <td>Subtotal</td>
                    <td id="subTotalCheckoutPageShow">Rp. <?= number_format($this->cart->total(), 0, ",", ".") ?></td>
                </tr>
                <?php if ($setting['shipping_feature'] == 1) { ?>
                    <tr>
                        <td>Biaya Ongkir</td>
                        <td id="ongkirCheckoutPage">Rp. 0</td>
                    </tr>
                <?php } ?>
                <?php if ($setting['potongan_feature'] == 1) { ?>
                    <tr>
                        <td>Potongan</td>
                        <td id="potonganCouponCheckoutPageShow">Rp. 0</td>
                    </tr>
                <?php } ?>
                <input type="hidden" name="potongan" id="potonganCouponCheckoutPageValue" value="0">
                <input type="hidden" id="valueOfFeeCODIfSelectCOD" value="0">
                <tr class="list-for-fee-cod-hide">
                    <td>Biaya COD <?= $this->Settings_model->general()['fee_cod']; ?>%</td>
                    <td class="valueOfUniqCodeOrFeeCODCheckoutPage"></td>
                </tr>
                <?php if ($setting['uniq_code_feature'] == 1) { ?>
                    <?php $randomNum = $setting['addmin_uniq'] == 1 ? rand(100, 999) : -rand(100, 999) ?>
                    <input type="hidden" id="valueRandomValueGenerateCheckoutPage" value="<?= $randomNum; ?>">
                    <tr class="list-for-uniq-code-show-first">
                        <td>Kode Unik</td>
                        <td>Rp. <?= $randomNum ?></td>
                    </tr>
                <?php } else { ?>
                    <?php $randomNum = 0; ?>
                <?php } ?>
                <tr>
                    <th>TOTAL</th>
                    <th id="totalCheckoutPage">Rp. <?= number_format($this->cart->total() + $randomNum, 0, ",", ".") ?></th>
                </tr>
                <input type="hidden" name="ongkir" value="0" id="ongkirValueOrder">
                <input type="hidden" name="random" value="<?= $randomNum; ?>" id="uniqueCodeValueOrder">
                <input type="hidden" name="payment" value="0" id="paymentLogoSelectCheckoutPageValue">
            </table>
        </div>
        <button type="submit" class="order_now btn_order_now_checkout_page" onClick="fbq('track', 'Lead');">PESAN SEKARANG</button>
    </form>
</div>