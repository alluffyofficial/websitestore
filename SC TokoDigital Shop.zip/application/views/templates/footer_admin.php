            </div>
            </div>


            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            <script>
                                document.write(new Date().getFullYear())
                            </script> © <?= $this->Settings_model->general()['app_name']; ?>.
                        </div>
                    </div>
                </div>
            </footer>

            </div>
            <!-- end main content-->

            </div>
            <!-- END layout-wrapper -->

            <!-- JAVASCRIPT -->
            <script src="<?= base_url(); ?>assets/admin/libs/jquery/jquery.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/metismenu/metisMenu.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/simplebar/simplebar.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/node-waves/waves.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/waypoints/lib/jquery.waypoints.min.js"></script>
            <script src="<?= base_url(); ?>assets/admin/libs/jquery.counterup/jquery.counterup.min.js"></script>

            <!-- apexcharts -->

            <script src="<?= base_url(); ?>assets/admin/js/app.js"></script>

            <script src="<?= base_url(); ?>assets/color-picker/dist/js/bootstrap-colorpicker.js"></script>

            <script src="<?= base_url(); ?>assets/select2-4.0.6-rc.1/dist/js/select2.min.js"></script>

            </body>

            <script>
                ClassicEditor
                    .create(document.querySelector('#description'))
                    .then(editor => {
                        console.log(editor);
                    })
                    .catch(error => {
                        console.error(error);
                    });

                $("#colorPicker").colorpicker();
                $("#colorPicker2").colorpicker();

                // order page
                function checkAllOrders() {
                    if ($("input.checkbox-order-page-main:checked").val() == "on") {
                        $("input.checkbox-order-page").attr("checked", true);
                    } else {
                        $("input.checkbox-order-page").attr("checked", false);
                    }
                }

                $("#socialProofStatusDesign").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/social_proof_status_change",
                        method: "get",
                        success: function(response) {
                            $("#msgSocialProofStatusDesign").show();
                            setTimeout(function() {
                                $("#msgSocialProofStatusDesign").hide();
                            }, 2000);
                        }
                    })
                })

                $("#chatHelpStatusDesign").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/chat_help_status_change",
                        method: "get",
                        success: function(response) {
                            $("#msgChatHelpStatusDesign").show();
                            setTimeout(function() {
                                $("#msgChatHelpStatusDesign").hide();
                            }, 2000);
                        }
                    })
                })

                $("#couponStatusOnCouponPage").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/coupon_status_change",
                        method: "get",
                        success: function(response) {
                            $("#msgCouponStatusOnCouponPage").show();
                            setTimeout(function() {
                                $("#msgCouponStatusOnCouponPage").hide();
                            }, 2000);
                        }
                    })
                })

                $("#paymentFeatureSetting").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/payment_feature_setting_change",
                        method: "get",
                        success: function(response) {
                            $("#msgSettingPayment").slideDown('fast');
                            $("#msgSettingPayment").text('Berhasil mengubah fitur pembayaran');
                            setTimeout(function() {
                                $("#msgSettingPayment").slideUp('fast');
                            }, 3000);
                        }
                    })
                })

                $("#uniqCodeFeatureSetting").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/uniq_code_feature_setting_change",
                        method: "get",
                        success: function(response) {
                            if (response == "1") {
                                $("#formGroupAddminUniqPayment").slideDown('fast');
                            } else {
                                $("#formGroupAddminUniqPayment").slideUp('fast');
                            }
                            $("#msgSettingPayment").slideDown('fast');
                            $("#msgSettingPayment").text('Berhasil mengubah fitur kode unik');
                            setTimeout(function() {
                                $("#msgSettingPayment").slideUp('fast');
                            }, 3000);
                        }
                    })
                })
                $("#paymentCODFeatureSetting").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/payment_cod_feature_setting_change",
                        method: "get",
                        success: function(response) {
                            if (response == 1) {
                                $("#formColumnFeeCODWrapper").slideUp('fast');
                            } else {
                                $("#formColumnFeeCODWrapper").slideDown('fast');
                            }
                        }
                    })
                })

                $("#shippingFeatureSetting").on('change', function() {
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/shipping_feature_setting_change",
                        method: "get",
                        success: function(response) {
                            $("#msgShippingSettingPage").slideDown('fast');
                            if (response == "1") {
                                $("#msgShippingSettingPage").text('Berhasil mengaktifkan fitur pengiriman');
                            } else {
                                $("#msgShippingSettingPage").text('Berhasil menonaktifkan fitur pengiriman');
                            }
                            setTimeout(function() {
                                $("#msgShippingSettingPage").slideUp('fast');
                            }, 3000);
                        }
                    })
                })

                $("#btnForApplyActionOrderPage").on("click", function(event) {
                    event.preventDefault();
                    let inputCheck = $(".checkbox-order-page:checked").map(function() {
                        return $(this).val();
                    }).get();
                    const action = $("#actionOrderPage").val();
                    if (action != null) {
                        $.ajax({
                            url: "<?= base_url(); ?>administrator/orders_set_status_action",
                            method: "post",
                            data: {
                                id: inputCheck,
                                status: action
                            },
                            success: function(response) {
                                if (action == 5) {
                                    swal({
                                        text: 'Data pesanan yang dipilih berhasil dihapus',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload(true);
                                    })
                                } else {
                                    swal({
                                        text: 'Status pesanan yang dipilih berhasil diubah',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload(true);
                                    })
                                }
                            }
                        })
                    }

                })

                if ($(".price-normal-product-addoredit").val() == "" || $(".price-normal-product-addoredit").val() == 0) {
                    $(".wholesaler-input").prop("disabled", true);
                }


                $(".price-normal-product-addoredit").on("keyup", function() {
                    if ($(".price-normal-product-addoredit").val() == "" || $(".price-normal-product-addoredit").val() == 0) {
                        $(".wholesaler-input").prop("disabled", true);
                    } else {
                        $(".wholesaler-input").prop("disabled", false);
                    }
                })

                $("#addWholesalerButton").on("click", function() {
                    $(".wrapper-wholesaler-core").append(`
                        <div class="col-md-4">
                            <input type="number" placeholder="Jumlah" autocomplete="off" name="wholesaler_count[]" class="form-control wholesaler-input mb-2">
                        </div>
                        <div class="col-md-8">
                            <input type="number" placeholder="Harga satuan" autocomplete="off" name="wholesaler_price[]" class="form-control wholesaler-input mb-2">
                        </div>
                    `);
                })

                let numberVariantAddProduct = 1;
                $("#btnAddVariantWhenAddProduct").on('click', function() {
                    $("#formGroupSectionVariantAddProduct").append(`
                <div class="row mt-2" id="sectionVariantAddProduct-${numberVariantAddProduct}">
                    <div class="col-lg-6">
                        <input
                        type="text"
                        class="form-control"
                        placeholder="Jenis"
                        name="variant_type[]"
                        autocomplete="off"
                        required
                        />	
                    </div>
                    <div class="col-lg-5">
                        <input
                        type="text"
                        class="form-control"
                        placeholder="Harga"
                        name="variant_price[]"
                        autocomplete="off"
                        required
                        />	
                    </div>
                    <div class="col-sm-1">
                        <i onclick="deleteVariantAddProduct('${numberVariantAddProduct}')" style="cursor: pointer" class="fa mt-2 fa-trash h4 text-danger"></i>
                    </div>
                </div>
            `);
                    numberVariantAddProduct += 1;
                })

                function deleteVariantAddProduct(id) {
                    $(`#sectionVariantAddProduct-${id}`).remove();
                }

                function deleteVariantFromDatabase(idvart, id) {
                    const confirmation = confirm('Yakin ingin menghapus varian ini?');
                    if (confirmation) {
                        $.ajax({
                            url: "<?= base_url(); ?>administrator/delete_variant_from_database/" + id,
                            method: "get",
                            success: function(response) {
                                if (response == true) {
                                    $(`#sectionVariantAddProduct-${idvart}`).remove();
                                }
                            }
                        })
                    }
                }

                function deleteImgGalleryProduct(sort, id) {
                    const confirmation = confirm('Yakin ingin menghapus gambar galeri ini?');
                    if (confirmation) {
                        $.ajax({
                            url: "<?= base_url(); ?>administrator/delete_gallery_img_from_database?id=" + id + "&sort=" + sort,
                            method: "get",
                            success: function(response) {
                                if (response == true) {
                                    $(`#gallery${sort}EditProduct`).remove();
                                    $(`#btnDeletegallery${sort}EditProduct`).remove();
                                }
                            }
                        })
                    }
                }

                function removeRekeningForm(id) {
                    $(`#formSectionSettingPayment-${id}`).slideUp('fast');
                }

                function deleteRekening(id) {
                    const aggre = confirm("Yakin ingin menghapus?");
                    if (aggre) {
                        $.ajax({
                            url: "<?= base_url(); ?>administrator/delete_rekening_from_database",
                            method: "post",
                            data: {
                                id: id
                            },
                            success: function(response) {
                                $(`#formSectionSettingPayment-${id}`).slideUp('fast');
                            }
                        })
                    }
                }

                $("#cityAdminSelectAddress").select2({
                    placeholder: 'Pilih Kabupaten/Kota',
                    language: 'id'
                })

                $("#cityAdminSelectAddress").on("change", function() {
                    $("#subdistrictAdminSelectAddress").html(`<option>Loading..</option>`);

                    const id = $(this).val();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/getSelectSubdistrictById",
                        type: "post",
                        dataType: "json",
                        async: true,
                        data: {
                            id: id
                        },
                        success: function(data) {
                            $("#subdistrictAdminSelectAddress").select2({
                                placeholder: 'Pilih Kecamatan',
                                language: 'id'
                            })
                            $("#subdistrictAdminSelectAddress").html(data);
                        }
                    });
                })

                $(function() {
                    $('.tools-text-editor button').click(function(e) {
                        document.execCommand($(this).data('role'));
                    });
                });

                $("#btnSaveSettingNotificationNewOrderPage").on('click', function() {
                    $("#btnSaveSettingNotificationNewOrderPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationNewOrderPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationNewOrderPage").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=1",
                        type: "post",
                        data: {
                            content: content
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi order baru berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationNewOrderPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationNewOrderPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#btnSaveSettingNotificationFollowUpPage").on('click', function() {
                    $("#btnSaveSettingNotificationFollowUpPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationFollowUpPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationFollowUp1Page").html();
                    const content2 = $("#contentSettingNotificationFollowUp2Page").html();
                    const content3 = $("#contentSettingNotificationFollowUp3Page").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=2",
                        type: "post",
                        data: {
                            content: content,
                            content2: content2,
                            content3: content3
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi follow up berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationFollowUpPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationFollowUpPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#btnSaveSettingNotificationConfirmationPage").on('click', function() {
                    $("#btnSaveSettingNotificationConfirmationPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationConfirmationPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationConfirmationPage").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=3",
                        type: "post",
                        data: {
                            content: content
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi konfirmasi berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationConfirmationPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationConfirmationPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#btnSaveSettingNotificationDeliveryPage").on('click', function() {
                    $("#btnSaveSettingNotificationDeliveryPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationDeliveryPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationDeliveryPage").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=4",
                        type: "post",
                        data: {
                            content: content
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi pengiriman berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationDeliveryPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationDeliveryPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#btnSaveSettingNotificationFinishPage").on('click', function() {
                    $("#btnSaveSettingNotificationFinishPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationFinishPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationFinishPage").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=5",
                        type: "post",
                        data: {
                            content: content
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi order selesai berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationFinishPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationFinishPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#btnSaveSettingNotificationCancelPage").on('click', function() {
                    $("#btnSaveSettingNotificationCancelPage").text("Sedang Menyimpan...");
                    $("#btnSaveSettingNotificationCancelPage").prop("disabled", true);
                    const content = $("#contentSettingNotificationCancelPage").html();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/insertNotificationSetting?type=6",
                        type: "post",
                        data: {
                            content: content
                        },
                        success: function(data) {
                            swal({
                                text: 'Notifikasi batal berhasi disimpan',
                                icon: 'success'
                            }).then(() => {
                                $("#btnSaveSettingNotificationCancelPage").text("Simpan Pengaturan");
                                $("#btnSaveSettingNotificationCancelPage").prop("disabled", false);
                            })
                        }
                    });
                })

                $("#typeSelectToSendNotificationWhatsAppInOrder").on("change", function() {
                    const id = $(this).val();
                    $.ajax({
                        url: "<?= base_url(); ?>administrator/getNotificationTable?id=" + id,
                        type: "get",
                        success: function(data) {
                            $("#contentSendNotificationToWhatsApp").html(data);
                        }
                    });
                })

                function showModalForActionWhatsappOrder(id) {
                    $("#idOrderActionWaOrder").val(id);
                }

                $("#btnSendNotificationToWhatsAppOrder").on("click", function() {
                    $("#btnSendNotificationToWhatsAppOrder").text("Mengirim..");
                    $("#btnSendNotificationToWhatsAppOrder").prop("disabled", true);
                    const id = $("#idOrderActionWaOrder").val();
                    const content = $("#contentSendNotificationToWhatsApp").html();
                    if (content != "") {
                        $.ajax({
                            url: "<?= base_url(); ?>administrator/getOrderDetailAjax/" + id,
                            type: "get",
                            dataType: "json",
                            async: true,
                            success: function(data) {
                                $.ajax({
                                    url: `<?= base_url(); ?>administrator/getFullAddressRO?subdistrict=${data.district}&city=${data.regency}`,
                                    method: "get",
                                    success: function(response) {
                                        $("#btnSendNotificationToWhatsAppOrder").text("Berhasil");
                                        $("#btnSendNotificationToWhatsAppOrder").prop("disabled", false);
                                        let message = content;
                                        let wa = data.telp.replace("08", "628");
                                        message = message.replace("[orderid]", data.invoice_code);
                                        message = message.replace("[nama]", data.name);
                                        message = message.replace("[phone]", data.telp);
                                        message = message.replace("[resi]", data.resi);
                                        message = message.replace("[courier]", data.courier.toUpperCase());
                                        let addressFromDb = encodeURI(data.address);
                                        let joinAddress = addressFromDb + ' ' + response + '%0A%0A';
                                        message = message.replace("[alamat]", joinAddress);
                                        message = message.replace(/<div><br><\/div>/g, "%0A%0A");
                                        message = message.replace(/<\/div><div>/g, "%0A");
                                        message = message.replace(/<div>/g, "");
                                        message = message.replace(/<br>/g, "");
                                        message = message.replace(/<\/div>/g, "");
                                        message = message.replace(/<b>/g, "*");
                                        message = message.replace(/<\/b>/g, "*");
                                        window.open(`https://wa.me/${wa}?text=${message}`);
                                    }
                                })
                            }
                        });
                    }
                })

                function exportTableToExcel(tableID, filename = '') {
                    var downloadLink;
                    var dataType = 'application/vnd.ms-excel';
                    var tableSelect = document.getElementById(tableID);
                    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');

                    // Specify file name
                    filename = filename ? filename + '.xls' : 'excel_data.xls';

                    // Create download link element
                    downloadLink = document.createElement("a");

                    document.body.appendChild(downloadLink);

                    if (navigator.msSaveOrOpenBlob) {
                        var blob = new Blob(['\ufeff', tableHTML], {
                            type: dataType
                        });
                        navigator.msSaveOrOpenBlob(blob, filename);
                    } else {
                        // Create a link to the file
                        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;

                        // Setting the file name
                        downloadLink.download = filename;

                        //triggering the function
                        downloadLink.click();
                    }
                }
            </script>

            </html>