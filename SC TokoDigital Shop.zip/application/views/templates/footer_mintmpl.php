<footer >
    <div class="copyright" style="background-color: <?= $this->config->item('subscribe'); ?>">
        <p class="mb-0">Copyright &copy; <span id="footer-cr-years"></span> <?= $this->Settings_model->general()["app_name"]; ?></p>
    </div>
</footer>