<?php
$setting = $this->Settings_model->getSetting();
$sosmed = $this->Settings_model->getSosmed();
$logopay = $this->db->get('logo_payment')->row_array();
?>
<footer>
    <div class="information">
        <div class="main">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()['logo-dark']; ?>" alt="logo" class="logo-footer" />
            <p class="description-store"><?= $setting['short_desc'] ?></p>
            <div class="payment_logo" style="text-align: center;">
                <?php if ($logopay['bca'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bca.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['mandiri'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/mandiri.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['bri'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bri.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['bni'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bni.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['bcas'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bcas.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['mandiris'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/mandiris.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['bris'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bris.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['bnis'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/bnis.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['jenius'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/jenius.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['ovo'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/ovo.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['dana'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/dana.png" alt="payment" class="logo_payment">
                <?php } ?>
                <?php if ($logopay['gopay'] == 1) { ?>
                    <img src="<?= base_url(); ?>assets/images/payment/gopay.png" alt="payment" class="logo_payment">
                <?php } ?>
            </div>
            <div class="social-media">
                <?php foreach ($sosmed->result_array() as $data) : ?>
                    <a href="<?= $data['link'] ?>" target="_blank"><i class="fa fa-<?= $data['icon'] ?>"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="copyright" style="background-color: <?= $this->config->item('subscribe'); ?>">
        <p class="mb-0">Copyright &copy; <span id="footer-cr-years"></span> <?= $this->Settings_model->general()["app_name"]; ?></p>
    </div>
</footer>