<nav class="navbar-top fixed-top shadow-sm" style="background-color: white;">
    <div class="main">
        <a href="<?= base_url(); ?>">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()['logo-dark']; ?>" alt="logo" class="logo">
        </a>
        <div class="menu">
            <a href="<?= base_url(); ?>">Home</a>
            <?php $this->db->join("pages", "menu.page=pages.id");
            $getmenu = $this->db->get('menu');
            foreach ($getmenu->result_array() as $d) : ?>
                <a href="<?= base_url(); ?><?= $d['slug']; ?>"><?= $d['title']; ?></a>
            <?php endforeach; ?>
        </div>
        <a href="#" data-toggle="modal" data-target="#modalCart" class="cart-link">
            <?php if ($this->cart->total_items() > 0) { ?>
                <img src="<?= base_url(); ?>assets/images/icon/shopping-bag.svg" alt="icon bag" class="shopping-bag">
                <p><?= count($this->cart->contents()); ?></p>
            <?php } else { ?>
                <img src="<?= base_url(); ?>assets/images/icon/shopping-bag.svg" alt="icon bag" class="shopping-bag">
            <?php } ?>
        </a>
    </div>
    <div class="main-mobile">
        <a href="<?= base_url(); ?>">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()["logo-dark"]; ?>" alt="logo" class="logo">
        </a>
        <div>
            <a href="#" data-toggle="modal" data-target="#modalCart" class="cart-link">
                <?php if ($this->cart->total_items() > 0) { ?>
                    <img src="<?= base_url(); ?>assets/images/icon/shopping-bag.svg" alt="icon bag" class="shopping-bag">
                    <p><?= count($this->cart->contents()); ?></p>
                <?php } else { ?>
                    <img src="<?= base_url(); ?>assets/images/icon/shopping-bag.svg" alt="icon bag" class="shopping-bag">
                <?php } ?>
            </a>
            <i class="fa fa-bars"></i>
        </div>
    </div>
</nav>
<div class="help-heigh-navbar-top"></div>
<!-- <nav class="navbar-top" style="background-color: <?= $this->Settings_model->general()["navbar_color"]; ?>">
    <div class="main">
        <a href="<?= base_url(); ?>">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()["logo"]; ?>" alt="logo" class="logo">
        </a>
        <form action="<?= base_url(); ?>search" method="get">
            <input type="text" placeholder="Cari produk" name="q" autocomplete="off">
            <i class="icofont-search"></i>
        </form>
        <a href="#" data-toggle="modal" data-target="#modalCart" class="cart-link">
            <?php if ($this->cart->total_items() > 0) { ?>
                <i class="fa fa-shopping-cart cart-icon"></i><p><?= count($this->cart->contents()); ?></p>
            <?php } else { ?>
                <i class="fa fa-shopping-cart cart-icon"></i>
            <?php } ?>
        </a>
    </div>
    <div class="main-mobile">
        <i class="fa fa-bars"></i>
        <a href="<?= base_url(); ?>">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()["logo"]; ?>" alt="logo" class="logo">
        </a>
        <a href="#" data-toggle="modal" data-target="#modalCart" class="cart-link">
            <?php if ($this->cart->total_items() > 0) { ?>
                <i class="fa fa-shopping-cart cart-icon"></i><p><?= count($this->cart->contents()); ?></p>
            <?php } else { ?>
                <i class="fa fa-shopping-cart cart-icon"></i>
            <?php } ?>
        </a>
    </div>
</nav> -->
<?php $this->db->join("pages", "menu.page=pages.id");
$getmenu = $this->db->get('menu'); ?>
<div class="overlay-menu"></div>
<div class="side-bar-menu-mobile">
    <div class="menu">
        <div class="img" style="background-color: <?= $this->Settings_model->general()["navbar_color"]; ?>">
            <img src="<?= base_url(); ?>assets/images/logo/<?= $this->Settings_model->general()["logo"]; ?>" alt="logo" class="logo">
        </div>
        <a href="<?= base_url(); ?>">Home</a>
        <?php foreach ($getmenu->result_array() as $d) : ?>
            <a href="<?= base_url(); ?><?= $d['slug']; ?>"><?= $d['title']; ?></a>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($this->Settings_model->getSetting()['chat_help'] == 1) { ?>
    <button name="button-chat" style="background-color: <?= $this->Settings_model->getSetting()['color_chat_help'] ?>" class="btn-chat-help-pojok-kanan-bawah"><i class="fab fa-whatsapp"></i></button>
    <div class="card box-chat-help-wa shadow">
        <div class="card-header top" style="background-color: <?= $this->Settings_model->getSetting()['color_chat_help'] ?>">
            <h4 class="lead mb-0 pt-0 pb-0 mt-0">Form Bantuan</h4>
        </div>
        <div class="card-body px-2 py-2">
            <input type="text" placeholder="Nama" id="formHelpInputNamePojokKananBawah" autocomplete="off" class="form-control">
            <textarea id="formHelpTextareaMessagePojokKananBawah" rows="4" class="form-control mt-2" placeholder="Tulis pesan.."></textarea>
            <button type="submit" id="btnFormHelpPojokKananBawah" style="background-color: <?= $this->Settings_model->getSetting()['color_chat_help'] ?>; font-size: 14px; color: white" class="btn mt-2 btn-block">KIRIM</button>
        </div>
    </div>
<?php } ?>