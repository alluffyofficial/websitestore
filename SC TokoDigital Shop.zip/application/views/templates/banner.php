<?php $banner = $this->Settings_model->getBanner(); ?>
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-pause="false" data-ride="carousel">
  <div class="carousel-inner">
    <?php
    foreach ($banner->result_array() as $key => $value) {
      $active = ($key == 0) ? 'active' : '';
      if ($value['url'] == '#') {
        echo '<div class="carousel-item ' . $active . '">
          <img alt="banner" src="' . base_url() . 'assets/images/banner/' . $value['img'] . '">
        </div>';
      } else {
        echo '<div class="carousel-item ' . $active . '">
          <a href="' . $value['url'] . '" target="_blank">
            <img alt="banner" src="' . base_url() . 'assets/images/banner/' . $value['img'] . '">
          </a>
        </div>';
      }
    }
    ?>
  </div>
</div>

<div class="search-inside-banner">
  <form action="<?= base_url(); ?>search" method="get">
    <input class="shadow-sm" type="text" placeholder="Cari produk" name="q" autocomplete="off">
    <i class="icofont-search"></i>
  </form>
</div>