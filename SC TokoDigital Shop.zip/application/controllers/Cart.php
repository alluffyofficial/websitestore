<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cart extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Categories_model');
        $this->load->model('Products_model');
        $this->load->library('cart');
    }

    public function add_to_cart()
    {
        $id = $this->input->post('id');
        $variant = $this->input->post('variant');
        $result = $this->db->get_where('products', ['id' => $id])->row_array();
        if ($variant == 1) {
            if ($result['variant1_discount'] == 0) {
                $price = $result['variant1_price'];
            } else {
                $diskonnya = ($result['variant1_price'] * $result['variant1_discount']) / 100;
                $price = $result['variant1_price'] - $diskonnya;
            }
        } else {
            if ($result['variant2_discount'] == 0) {
                $price = $result['variant2_price'];
            } else {
                $diskonnya = ($result['variant2_price'] * $result['variant2_discount']) / 100;
                $price = $result['variant2_price'] - $diskonnya;
            }
        }

        $productIsEmpty = true;
        $rowidProductInCart = "";
        $qtyProductInCart = "";
        foreach ($this->cart->contents() as $item) {
            if ($item['slug'] == $result['slug']) {
                if ($variant == 1) {
                    if ($item['variant'] == $result['variant1']) {
                        $productIsEmpty = false;
                        $rowidProductInCart = $item['rowid'];
                        $qtyProductInCart = $item['qty'];
                    }
                }
                if ($variant == 2) {
                    if ($item['variant'] == $result['variant2']) {
                        $productIsEmpty = false;
                        $rowidProductInCart = $item['rowid'];
                        $qtyProductInCart = $item['qty'];
                    }
                }
            }
        }

        if ($result['img'] == "") {
            $imgfix = $this->getThumbnail($result['video_yt']);
        } else {
            $imgfix =  $result['ex_img'] == 1 ? $result['img'] : base_url() . 'assets/images/product/' . $result['img'];
        }

        if ($productIsEmpty) {
            $data = array(
                'id' => time(),
                'name' => $result['title'],
                'price' => $price,
                'qty' => 1,
                'img' => $imgfix,
                'ex_img' => $result['ex_img'],
                'slug' => $result['slug'],
                'weight' => $result['weight'],
                'variant' => $variant == 1 ? $result['variant1'] : $result['variant2']
            );
            $this->cart->insert($data);
        } else {
            $qty = $qtyProductInCart + 1;
            $data = [
                'rowid' => $rowidProductInCart,
                'qty' => $qty,
            ];
            $this->cart->update($data);
        }

        $list = "";
        foreach ($this->cart->contents() as $item) {
            $list .= '<div class="item-cart" id="modalCartBodyListItem-' . $item['rowid'] . '">
            <img src="' . $item["img"] . '" alt="img product" class="thumb-img">
            <div class="text">
            <h4 class="product-name">' . $item['name'] . '</h4>
            <p class="information mb-0">' . $item["variant"] . '</p>
            <h5 class="price" id="modalCartPriceProduct-' . $item['rowid'] . '">Rp. ' . number_format($item['subtotal'], 0, ",", ".") . '</h5>
            </div>
            <div class="option">
            <div></div>
            <div class="qty">';
            $list .= '<button style="border-top-left-radius: 6px;border-bottom-left-radius: 6px;" onclick="minusProductCart(\'' . $item['rowid'] . '\')">-</button>
            <input disabled type="text" value="' . $item['qty'] . '" id="qtyProductCart-' . $item['rowid'] . '" class="valueJmlQty">
            <button style="border-top-right-radius: 6px;border-bottom-right-radius: 6px;" onclick="plusProductCart(\'' . $item['rowid'] . '\')">+</button>
            </div>
            </div>
            <i class="fa fa-trash text-danger" onclick="deleteCartByRowid(\'' . $item['rowid'] . '\')"></i>
            </div>';
        }
        $list .= '<div class="button-bottom-modal-cart-global">
                <button type="button" onclick="location.reload(true)" class="shopping-again" data-dismiss="modal">BELANJA LAGI</button>
                <a href="' . base_url() . 'checkout" class="checkout"><button>LANJUT CHECKOUT</button></a>
            </div>';

        echo $list;
    }

    public function get_item()
    {
        $rowid = $this->input->post('rowid');
        echo json_encode($this->cart->get_item($rowid));
    }

    public function add_ket()
    {
        $rowid = $this->input->post('rowid');
        $ket = $this->input->post('ket');
        $data = [
            'rowid' => $rowid,
            'ket' => $ket,
        ];
        $this->cart->update($data);
    }

    public function edit_qty_cart()
    {
        $type = $_GET['type'];
        $rowid = $this->input->post('rowid');
        $cart = $this->cart->get_item($rowid);
        if ($type == "minus") {
            $qty = $cart['qty'] - 1;
            $data = [
                'rowid' => $rowid,
                'qty' => $qty,
            ];
            $this->cart->update($data);
        } else if ($type == "plus") {
            $qty = $cart['qty'] + 1;
            $data = [
                'rowid' => $rowid,
                'qty' => $qty,
            ];
            $this->cart->update($data);
        }
        echo $this->cart->get_item($rowid)['subtotal'];
    }

    public function delete($id)
    {
        $data = [
            'rowid' => $id,
            'qty' => 0
        ];
        $this->cart->update($data);
    }

    public function delete_cart()
    {
        $this->cart->destroy();
        redirect(base_url() . 'cart');
    }

    function getThumbnail($url)
    {
        preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $url, $matches);
        return "https://img.youtube.com/vi/$matches[0]/0.jpg";
    }
}
