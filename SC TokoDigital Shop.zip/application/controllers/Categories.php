<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Categories extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Categories_model');
		$this->load->model('Products_model');
	}

	public function index($c)
	{
		$cat = $this->Categories_model->getIdCategoryBySlug($c);
		$data['products'] = $this->Products_model->getAllProductsByCategory($cat['id'], 0, "");
		$data['title'] = 'Kategori ' . $this->Categories_model->getNameCategoryBySlug($c) . ' - ' . $this->Settings_model->general()["app_name"];
		$data['css'] = 'style';
		$data['category'] = $cat['name'];
		$data['responsive'] = 'style-responsive';
		$data['slug'] = $cat['slug'];
		$data['idCat'] = $cat['id'];
		$this->load->view('templates/header', $data);
		$this->load->view('templates/navbar');
		$this->load->view('page/categories', $data);
		$this->load->view('templates/footer_tmpl');
		$this->load->view('templates/footer_real');
	}
}
