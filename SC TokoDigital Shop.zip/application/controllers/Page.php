<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Page extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Categories_model');
	}

	public function index($slug)
	{
		$page = $this->Settings_model->getPageBySlug($slug);
		if ($page == NULL) {
			redirect(base_url() . '404');
		} else {
			$data['title'] = $page['title'] . ' - ' . $this->Settings_model->general()["app_name"];
			$data['css'] = 'page';
			$data['page'] = $page;
			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('page/page', $page);
			$this->load->view('templates/footer_tmpl');
			$this->load->view('templates/footer_real');
		}
	}

	public function search()
	{
		$q = $_GET['q'];
		$word = ["<script>", "<img", "<h1>", "<h2>", "<h3>", "<h4>", "<h5>", "<h6>"];
		$q = str_replace($word, "", $q);
		$data['products'] = $this->Products_model->searchProducts($q, "");
		$data['title'] = 'Hasil pencarian : ' . $q;
		$data['css'] = 'style';
		$data['responsive'] = 'style-responsive';
		$data['q'] = $q;
		$this->load->view('templates/header', $data);
		$this->load->view('templates/navbar');
		$this->load->view('page/search', $data);
		$this->load->view('templates/footer_tmpl');
		$this->load->view('templates/footer_real');
	}

	public function tracking()
	{
		$invoice = $_GET['invoice'];
		$wa = $_GET['wa'];
		$check = $this->db->get_where('invoice', ['invoice_code' => $invoice, 'telp' => $wa])->row_array();
		if ($check) {
			$data['order'] = $check;
		} else {
			$data['order'] = "";
		}
		$data['title'] = 'Cek Pesanan - ' . $this->Settings_model->general()['app_name'];
		$data['css'] = 'tracking';
		$data['invoice'] = $invoice;
		$data['wa'] = $wa;
		$this->load->view('templates/header', $data);
		$this->load->view('templates/navbar');
		$this->load->view('page/tracking', $data);
		$this->load->view('templates/footer_tmpl');
		$this->load->view('templates/footer_real');
	}
}
