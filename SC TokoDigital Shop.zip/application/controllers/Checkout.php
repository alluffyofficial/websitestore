<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Checkout extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Payment_model');
        if ($this->cart->total_items() == 0) {
            redirect(base_url());
        }
    }

    public function index()
    {
        $data['title'] = 'Checkout - ' . $this->Settings_model->general()["app_name"];
        $data['css'] = 'checkout';
        $data['responsive'] = '';
        $data['setting'] = $this->Settings_model->getSetting();
        $this->db->select("*, rekening.id as rekeningId, bank.name AS bankName");
        $this->db->join("bank", "bank.id=rekening.rekening");
        $data['payment'] = $this->db->get('rekening');
        $data['logo_pay'] = $this->db->get('logo_payment')->row_array();
        $this->load->view('templates/header', $data);
        $this->load->view('page/checkout');
        $this->load->view('templates/footer_mintmpl');
        $this->load->view('templates/footer_real');
    }

    public function checkoutCoupon()
    {
        $coupon = $this->input->post('coupon');
        $check = $this->db->get_where('coupon', ['code' => $coupon])->row_array();
        if ($check) {
            if ($check['dated'] >= date('Y-m-d')) {
                if ($this->cart->total() >= $check['min']) {
                    if ($check['type'] == 1) {
                        $diskonnya = ($this->cart->total() * $check['discount']) / 100;
                        $price = $this->cart->total() - $diskonnya;
                        echo json_encode(["success" => true, "discount" => $diskonnya]);
                    } else {
                        echo json_encode(["success" => true, "discount" => $check['discount']]);
                    }
                } else {
                    $priceHarusnya = number_format($check['min'], 0, ",", ".");
                    echo json_encode(["success" => false, "msg" => "Belanja minimal Rp.$priceHarusnya untuk menggunakan kupon ini"]);
                }
            } else {
                echo json_encode(["success" => false, "msg" => "Kode kupon yang dimasukkan sudah habis masa berlaku"]);
            }
        } else {
            echo json_encode(["success" => false, "msg" => "Kode kupon yang dimasukan tidak tersedia"]);
        }
    }

    public function go()
    {
        $invoice = time();
        $name = $this->input->post('name');
        $wa = $this->input->post('wa');
        $random = $this->input->post('random');
        $potongan = $this->input->post('potongan');
        $payment = $this->input->post('payment');
        $totalall = intval($this->cart->total()) + intval($random) - intval($potongan);
        if ($name != "" && $wa != "") {
            $dataIns = [
                'invoice_code' => $invoice,
                'name' => $name,
                'telp' => $wa,
                'total_price' => $this->cart->total(),
                'uniq_number' => $random,
                'total_all' => $totalall,
                'potongan' => $potongan,
                'date_input' => date('Y-m-d H:i:s'),
                'dated' => date('Y-m-d'),
                'payment' => $payment
            ];
            $this->db->insert('invoice', $dataIns);
            foreach ($this->cart->contents() as $c) {
                $data = [
                    'id_invoice' => $invoice,
                    'product_name' => $c['name'],
                    'price' => $c['price'],
                    'qty' => $c['qty'],
                    'slug' => $c['slug'],
                    'variant' => $c['variant'],
                ];
                $this->db->insert('transaction', $data);
            }
            $list = '';
            $nom = 1;
            foreach ($this->cart->contents() as $c) {
                $list .= '*' . $nom . '. ' . $c['name'] . '*%0A';
                $list .= 'Jumlah: ' . $c['qty'] . '%0A';
                $list .= 'Varian: ' . $c['variant'] . '%0A';
                $list .= 'Harga Satuan: Rp ' . number_format($c['price'], 0, ",", ".") . '%0A';
                $list .= 'Harga Total: Rp ' . number_format($c['subtotal'], 0, ",", ".") . '%0A';
                $nom++;
            }
            $list .= '%0A';
            $list .= 'Subtotal: *Rp ' . number_format($this->cart->total(), 0, ",", ".") . '*%0A';
            $list .= 'Kode Unik: *Rp ' . $random . '*%0A';
            if ($potongan != "0") {
                $list .= 'Potongan: *Rp ' . number_format($potongan, 0, ",", ".") . '*%0A';
            }
            $list .= 'Total: *Rp ' . number_format($totalall, 0, ",", ".") . '*%0A';
            $list .= '-----------------------%0A';
            $list .= '*Nama:*%0A';
            $list .= $name . ' (' . $wa . ')%0A%0A';
            if ($this->input->post('payment') != "0") {
                $rekening = $this->db->get_where('rekening', ['rekening' => $this->input->post('payment')])->row_array();
                $bank = $this->db->get_where('bank', ['id' => $rekening['rekening']])->row_array();
                $list .= '*Pembayaran:*%0A';
                $list .= $bank['name'] . '%0A';
                $list .= $rekening['number'] . ' an ' . $rekening['name'];
            }
            $this->cart->destroy();
            $setting = $this->Settings_model->getSetting();
            $waadmin = $setting['wa_admin'];
            $msgChat = $setting['opening_chat'];
            redirect("https://wa.me/$waadmin?text=$msgChat %0A%0A" . $list);
        } else {
            redirect(base_url() . 'checkout');
        }
    }
}
